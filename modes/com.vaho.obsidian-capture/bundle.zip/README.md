# Obsidian Capture

Append quick notes to an Obsidian vault straight from the notch.

## Setup

1. In Obsidian, install and enable the community plugin **Local REST API**
   (Settings → Community plugins → Browse → "Local REST API").
2. In the plugin's settings, either:
   - copy the **API key** it generates and use the default HTTPS port
     `https://127.0.0.1:27124` (self-signed certificate — some networking
     stacks reject it), or
   - turn on **"Enable Non-encrypted (HTTP) Server"** and use
     `http://127.0.0.1:27123` instead (simplest, loopback-only so it never
     leaves your Mac).
3. Open this mode's settings (gear icon), paste the base URL and API key,
   and set a **file pattern** — the vault-relative path notes get appended
   to. `{YYYY}`, `{MM}`, `{DD}` are replaced with today's date, so
   `Daily/{YYYY}-{MM}-{DD}.md` targets a daily-notes-style vault; a plain
   `Inbox.md` always appends to the same file. The file is created if it
   doesn't exist yet.
4. Type, ⌘⏎ or the Capture button appends it.

Nothing is sent anywhere but `127.0.0.1`/`localhost` — see `allowedHosts` in
`manifest.json`.
