(() => {
  "use strict";

  const lang = (navigator.language || "en").slice(0, 2);
  const STRINGS = {
    en: {
      currency: "Currency", length: "Length", weight: "Weight", temperature: "Temp",
      speed: "Speed", data: "Data", volume: "Volume", area: "Area", time: "Time",
      from: "From", to: "To",
      swap: "Swap", search: "Search units", updated: "ECB rate · {0}",
      offline: "Rates unavailable — showing last known", loading: "Fetching rates…",
      month: "30 days", invalid: "Type a number or a sum like 12*3"
    },
    es: {
      currency: "Divisa", length: "Longitud", weight: "Peso", temperature: "Temp.",
      speed: "Velocidad", data: "Datos", volume: "Volumen", area: "Área", time: "Tiempo",
      from: "De", to: "A",
      swap: "Intercambiar", search: "Buscar unidades", updated: "Tipo BCE · {0}",
      offline: "Sin conexión — últimos tipos conocidos", loading: "Obteniendo tipos…",
      month: "30 días", invalid: "Escribe un número o una operación como 12*3"
    }
  };
  const S = STRINGS[lang] || STRINGS.en;
  const fmt = (s, ...a) => s.replace(/\{(\d)\}/g, (_, i) => a[i]);

  // ---------- units ----------
  // [id, symbol, name, factor to the category's base unit]
  const UNITS = {
    length: [
      ["mm", "mm", "Millimeter", 0.001], ["cm", "cm", "Centimeter", 0.01], ["m", "m", "Meter", 1],
      ["km", "km", "Kilometer", 1000], ["in", "in", "Inch", 0.0254], ["ft", "ft", "Foot", 0.3048],
      ["yd", "yd", "Yard", 0.9144], ["mi", "mi", "Mile", 1609.344], ["nmi", "nmi", "Nautical mile", 1852]
    ],
    weight: [
      ["mg", "mg", "Milligram", 1e-6], ["g", "g", "Gram", 0.001], ["kg", "kg", "Kilogram", 1],
      ["t", "t", "Tonne", 1000], ["oz", "oz", "Ounce", 0.028349523125], ["lb", "lb", "Pound", 0.45359237],
      ["st", "st", "Stone", 6.35029318]
    ],
    temperature: [
      ["c", "°C", "Celsius"], ["f", "°F", "Fahrenheit"], ["k", "K", "Kelvin"]
    ],
    speed: [
      ["ms", "m/s", "Meters / second", 1], ["kmh", "km/h", "Kilometers / hour", 1 / 3.6],
      ["mph", "mph", "Miles / hour", 0.44704], ["kn", "kn", "Knot", 0.514444], ["fts", "ft/s", "Feet / second", 0.3048]
    ],
    data: [
      ["bit", "bit", "Bit", 0.125], ["b", "B", "Byte", 1], ["kb", "KB", "Kilobyte", 1e3], ["mb", "MB", "Megabyte", 1e6],
      ["gb", "GB", "Gigabyte", 1e9], ["tb", "TB", "Terabyte", 1e12], ["kib", "KiB", "Kibibyte", 1024],
      ["mib", "MiB", "Mebibyte", 1024 ** 2], ["gib", "GiB", "Gibibyte", 1024 ** 3], ["tib", "TiB", "Tebibyte", 1024 ** 4]
    ],
    volume: [
      ["ml", "mL", "Milliliter", 0.001], ["l", "L", "Liter", 1], ["m3", "m³", "Cubic meter", 1000],
      ["tsp", "tsp", "Teaspoon (US)", 0.00492892], ["tbsp", "tbsp", "Tablespoon (US)", 0.0147868],
      ["floz", "fl oz", "Fluid ounce (US)", 0.0295735], ["cup", "cup", "Cup (US)", 0.236588],
      ["pt", "pt", "Pint (US)", 0.473176], ["gal", "gal", "Gallon (US)", 3.78541]
    ],
    area: [
      ["cm2", "cm²", "Square centimeter", 1e-4], ["m2", "m²", "Square meter", 1], ["ha", "ha", "Hectare", 1e4],
      ["km2", "km²", "Square kilometer", 1e6], ["ft2", "ft²", "Square foot", 0.09290304],
      ["ac", "ac", "Acre", 4046.8564224], ["mi2", "mi²", "Square mile", 2589988.110336]
    ],
    time: [
      ["ms", "ms", "Millisecond", 0.001], ["s", "s", "Second", 1], ["min", "min", "Minute", 60],
      ["h", "h", "Hour", 3600], ["d", "d", "Day", 86400], ["wk", "wk", "Week", 604800],
      ["yr", "yr", "Year", 31557600]
    ],
    currency: []
  };
  const CATEGORIES = ["currency", "length", "weight", "temperature", "speed", "data", "volume", "area", "time"];
  const DEFAULTS = {
    currency: ["USD", "EUR"], length: ["km", "mi"], weight: ["kg", "lb"], temperature: ["c", "f"],
    speed: ["kmh", "mph"], data: ["gb", "gib"], volume: ["l", "gal"], area: ["m2", "ft2"], time: ["h", "min"]
  };
  const CURRENCY_NAMES = {
    AUD: "Australian Dollar", BRL: "Brazilian Real", CAD: "Canadian Dollar", CHF: "Swiss Franc",
    CNY: "Chinese Yuan", CZK: "Czech Koruna", DKK: "Danish Krone", EUR: "Euro", GBP: "British Pound",
    HKD: "Hong Kong Dollar", HUF: "Hungarian Forint", IDR: "Indonesian Rupiah", ILS: "Israeli Shekel",
    INR: "Indian Rupee", ISK: "Icelandic Króna", JPY: "Japanese Yen", KRW: "South Korean Won",
    MXN: "Mexican Peso", MYR: "Malaysian Ringgit", NOK: "Norwegian Krone", NZD: "New Zealand Dollar",
    PHP: "Philippine Peso", PLN: "Polish Złoty", RON: "Romanian Leu", SEK: "Swedish Krona",
    SGD: "Singapore Dollar", THB: "Thai Baht", TRY: "Turkish Lira", USD: "US Dollar", ZAR: "South African Rand"
  };
  UNITS.currency = Object.entries(CURRENCY_NAMES).map(([code, name]) => [code, code, name]);

  const flag = code => {
    const cc = code === "EUR" ? "EU" : code.slice(0, 2);
    return String.fromCodePoint(...[...cc].map(c => 0x1f1a5 + c.charCodeAt(0)));
  };

  function convert(cat, value, from, to) {
    if (cat === "temperature") {
      const c = from === "c" ? value : from === "f" ? (value - 32) * 5 / 9 : value - 273.15;
      return to === "c" ? c : to === "f" ? c * 9 / 5 + 32 : c + 273.15;
    }
    if (cat === "currency") {
      const r = rates.get(from);
      if (!r) return null;
      return from === to ? value : r.rates[to] != null ? value * r.rates[to] : null;
    }
    const u = id => UNITS[cat].find(x => x[0] === id)[3];
    return (value * u(from)) / u(to);
  }

  // ---------- safe arithmetic ----------
  // Accepts numbers with either decimal mark, + − × ÷ * / ^ %, and parentheses.
  function evaluate(text) {
    const src = text.replace(/\s+/g, "").replace(/[×x]/g, "*").replace(/÷/g, "/").replace(/−/g, "-");
    if (!src) return null;
    const norm = src.replace(/(\d)[.,](?=\d{3}(\D|$))(?=.*[.,]\d)/g, "$1").replace(/,/g, ".");
    let i = 0;
    const peek = () => norm[i];
    function expr() {
      let v = term();
      while (peek() === "+" || peek() === "-") { const op = norm[i++]; const r = term(); v = op === "+" ? v + r : v - r; }
      return v;
    }
    function term() {
      let v = power();
      while (peek() === "*" || peek() === "/") { const op = norm[i++]; const r = power(); v = op === "*" ? v * r : v / r; }
      return v;
    }
    function power() {
      const b = unary();
      if (peek() === "^") { i++; return Math.pow(b, power()); }
      return b;
    }
    function unary() {
      if (peek() === "-") { i++; return -unary(); }
      if (peek() === "+") { i++; return unary(); }
      let v = atom();
      if (peek() === "%") { i++; v /= 100; }
      return v;
    }
    function atom() {
      if (peek() === "(") { i++; const v = expr(); if (norm[i++] !== ")") throw 0; return v; }
      const m = /^\d*\.?\d+(e[+-]?\d+)?/i.exec(norm.slice(i));
      if (!m) throw 0;
      i += m[0].length;
      return parseFloat(m[0]);
    }
    try {
      const v = expr();
      return i === norm.length && Number.isFinite(v) ? v : null;
    } catch { return null; }
  }

  function format(n, cat) {
    if (n == null || !Number.isFinite(n)) return "—";
    const a = Math.abs(n);
    if (a !== 0 && (a >= 1e15 || a < 1e-6)) return n.toExponential(4).replace("e+", "e");
    const digits = cat === "currency" ? (a >= 1 ? 2 : 4) : a >= 1000 ? 2 : a >= 1 ? 4 : 6;
    return new Intl.NumberFormat(lang, { maximumFractionDigits: digits }).format(n);
  }

  // ---------- currency rates ----------
  const HOST = "https://api.frankfurter.dev/v1";
  const rates = new Map();       // base → { date, rates }
  const history = new Map();     // "USD>EUR" → [values]
  let rateState = "idle";

  async function loadRates(base) {
    const cached = rates.get(base);
    if (cached && Date.now() - cached.fetchedAt < 3600e3) return;
    const stored = await store.get("rates:" + base);
    if (stored && !rates.has(base)) rates.set(base, stored);
    if (stored && Date.now() - stored.fetchedAt < 3600e3) return;
    rateState = "loading";
    renderMeta();
    try {
      const r = await vaho.net.fetch(`${HOST}/latest?base=${base}`);
      if (!r.ok) throw new Error(r.status);
      const j = r.json();
      const entry = { date: j.date, rates: { ...j.rates, [base]: 1 }, fetchedAt: Date.now() };
      rates.set(base, entry);
      store.set("rates:" + base, entry);
      rateState = "ok";
    } catch {
      rateState = rates.has(base) ? "stale" : "error";
    }
  }

  async function loadHistory(from, to) {
    const key = from + ">" + to;
    if (history.has(key) || from === to) return;
    history.set(key, null);
    try {
      const start = new Date(Date.now() - 32 * 864e5).toISOString().slice(0, 10);
      const r = await vaho.net.fetch(`${HOST}/${start}..?base=${from}&symbols=${to}`);
      const j = r.json();
      const pts = Object.keys(j.rates).sort().map(d => j.rates[d][to]);
      history.set(key, pts);
    } catch {
      history.delete(key);
    }
  }

  // ---------- storage ----------
  const store = {
    async get(k) { try { return await vaho.storage.get(k); } catch { return null; } },
    set(k, v) { try { vaho.storage.set(k, v).catch(() => {}); } catch {} }
  };

  // ---------- state ----------
  const state = {
    cat: "currency",
    pairs: { ...DEFAULTS },
    input: "100"
  };

  const $ = s => document.querySelector(s);
  const amount = $("#amount");
  const result = $("#result");
  let shown = null;

  function unitInfo(cat, id) {
    const u = UNITS[cat].find(x => x[0] === id) || UNITS[cat][0];
    return { id: u[0], sym: u[1], name: u[2] };
  }

  function renderTabs() {
    const box = $("#tabs");
    box.innerHTML = CATEGORIES.map(c => `<button class="tab${c === state.cat ? " on" : ""}" data-cat="${c}">${S[c]}</button>`).join("") + `<span class="tab-ink" id="ink"></span>`;
    moveInk(false);
  }
  function moveInk(animate) {
    const on = $(".tab.on"), ink = $("#ink");
    if (!on || !ink) return;
    ink.style.transition = animate ? "" : "none";
    ink.style.width = on.offsetWidth + "px";
    ink.style.transform = `translateX(${on.offsetLeft}px)`;
    if (animate) {
      const box = $("#tabs");
      const target = on.offsetLeft - (box.clientWidth - on.offsetWidth) / 2;
      box.scrollTo({ left: target, behavior: "smooth" });
    }
  }

  function renderUnits() {
    const [from, to] = state.pairs[state.cat];
    for (const [el, nameEl, id] of [[$("#from-unit"), $("#from-unit-name"), from], [$("#to-unit"), $("#to-unit-name"), to]]) {
      const u = unitInfo(state.cat, id);
      el.querySelector(".u-flag").textContent = state.cat === "currency" ? flag(u.id) : "";
      el.querySelector(".u-flag").hidden = state.cat !== "currency";
      el.querySelector(".u-sym").textContent = u.sym;
      nameEl.textContent = u.name;
    }
  }

  function compute(animate) {
    const [from, to] = state.pairs[state.cat];
    const v = evaluate(state.input);
    $("#from-card").classList.toggle("bad", v == null && state.input.trim() !== "");
    const out = v == null ? null : convert(state.cat, v, from, to);
    $("#expr").textContent = v != null && /[-+*/^%()×÷]/.test(state.input.trim().replace(/^-/, "")) ? "= " + format(v, state.cat) : "";
    tween(out, animate);
    renderMeta();
  }

  let raf = 0;
  function tween(target, animate) {
    cancelAnimationFrame(raf);
    const cat = state.cat;
    if (target == null || shown == null || !animate || !Number.isFinite(shown) || Math.sign(shown) !== Math.sign(target)) {
      shown = target;
      result.textContent = format(target, cat);
      fit(result);
      return;
    }
    const from = shown, t0 = performance.now();
    const step = now => {
      const k = Math.min(1, (now - t0) / 380);
      const e = 1 - Math.pow(1 - k, 3);
      shown = from + (target - from) * e;
      result.textContent = format(k >= 1 ? target : shown, cat);
      fit(result);
      if (k < 1) raf = requestAnimationFrame(step);
      else shown = target;
    };
    raf = requestAnimationFrame(step);
  }

  // Shrink long numbers so they never overflow the card.
  function fit(el) {
    const len = el.textContent.length;
    el.style.fontSize = len > 13 ? "17px" : len > 10 ? "21px" : "26px";
  }

  function renderMeta() {
    const [from, to] = state.pairs[state.cat];
    const meta = $("#meta");
    const spark = $("#spark");
    if (state.cat === "currency") {
      const r = rates.get(from);
      if (!r) {
        meta.textContent = rateState === "error" ? S.offline : S.loading;
        spark.classList.remove("on");
        return;
      }
      const one = convert("currency", 1, from, to);
      const date = new Intl.DateTimeFormat(lang, { day: "numeric", month: "short" }).format(new Date(r.date + "T12:00:00"));
      meta.innerHTML = `<b>1 ${from} = ${format(one, "currency").replace(/(\.\d{2})$/, "$1")} ${to}</b><span>${fmt(S.updated, date)}${rateState === "stale" ? " · ⚠︎" : ""}</span>`;
      drawSpark(history.get(from + ">" + to));
    } else {
      const one = convert(state.cat, 1, from, to);
      const a = unitInfo(state.cat, from), b = unitInfo(state.cat, to);
      meta.innerHTML = `<b>1 ${a.sym} = ${format(one, state.cat)} ${b.sym}</b><span>${a.name} → ${b.name}</span>`;
      spark.classList.remove("on");
    }
  }

  function drawSpark(points) {
    const spark = $("#spark");
    if (!points || points.length < 2) { spark.classList.remove("on"); return; }
    const w = 96, h = 26, pad = 2;
    const min = Math.min(...points), max = Math.max(...points);
    const span = max - min || 1;
    const xy = points.map((p, i) => [pad + (i / (points.length - 1)) * (w - pad * 2), pad + (1 - (p - min) / span) * (h - pad * 2)]);
    const line = xy.map((p, i) => (i ? "L" : "M") + p[0].toFixed(1) + " " + p[1].toFixed(1)).join("");
    const up = points[points.length - 1] >= points[0];
    const change = ((points[points.length - 1] / points[0] - 1) * 100);
    spark.classList.toggle("down", !up);
    spark.querySelector(".line").setAttribute("d", line);
    spark.querySelector(".area").setAttribute("d", `${line}L${w - pad} ${h}L${pad} ${h}Z`);
    const last = xy[xy.length - 1];
    spark.querySelector(".dot").setAttribute("cx", last[0]);
    spark.querySelector(".dot").setAttribute("cy", last[1]);
    $("#spark-change").textContent = `${change >= 0 ? "+" : ""}${change.toFixed(2)}%`;
    $("#spark-label").textContent = S.month;
    const path = spark.querySelector(".line");
    const len = path.getTotalLength();
    path.style.setProperty("--len", len);
    path.style.strokeDasharray = len;
    path.style.animation = "none";
    void path.getBoundingClientRect();
    path.style.animation = "";
    spark.classList.add("on");
  }

  async function refreshCurrency() {
    if (state.cat !== "currency") return;
    const [from, to] = state.pairs.currency;
    await loadRates(from);
    compute(true);
    await loadHistory(from, to);
    if (state.cat === "currency" && state.pairs.currency[0] === from && state.pairs.currency[1] === to) renderMeta();
  }

  function save() {
    store.set("converter", { cat: state.cat, pairs: state.pairs, input: state.input });
  }

  // ---------- interactions ----------
  $("#tabs").addEventListener("click", e => {
    const b = e.target.closest(".tab");
    if (!b || b.dataset.cat === state.cat) return;
    const dir = CATEGORIES.indexOf(b.dataset.cat) > CATEGORIES.indexOf(state.cat) ? 1 : -1;
    state.cat = b.dataset.cat;
    document.querySelectorAll(".tab").forEach(t => t.classList.toggle("on", t === b));
    moveInk(true);
    const stage = $("#cards");
    stage.style.setProperty("--dir", dir);
    stage.classList.remove("switch");
    void stage.offsetWidth;
    stage.classList.add("switch");
    shown = null;
    renderUnits();
    compute(false);
    refreshCurrency();
    save();
    window.vaho?.haptic?.();
  });

  amount.addEventListener("input", () => {
    state.input = amount.value;
    compute(true);
    save();
  });
  amount.addEventListener("keydown", e => {
    if (e.key === "ArrowUp" || e.key === "ArrowDown") {
      e.preventDefault();
      const v = evaluate(state.input) ?? 0;
      const step = e.shiftKey ? 10 : 1;
      state.input = String(+(v + (e.key === "ArrowUp" ? step : -step)).toFixed(10));
      amount.value = state.input;
      compute(true);
      save();
    } else if (e.key === "Enter") {
      const v = evaluate(state.input);
      if (v != null) { state.input = String(+v.toFixed(10)); amount.value = state.input; compute(false); save(); }
    }
  });

  $("#swap").addEventListener("click", () => {
    const pair = state.pairs[state.cat];
    const v = evaluate(state.input);
    const out = v == null ? null : convert(state.cat, v, pair[0], pair[1]);
    state.pairs[state.cat] = [pair[1], pair[0]];
    if (out != null) {
      const digits = state.cat === "currency" ? 2 : 6;
      state.input = String(+out.toFixed(digits));
      amount.value = state.input;
    }
    const cards = $("#cards");
    cards.classList.remove("swapping");
    void cards.offsetWidth;
    cards.classList.add("swapping");
    $("#swap").classList.toggle("turned");
    shown = null;
    renderUnits();
    compute(false);
    refreshCurrency();
    save();
    window.vaho?.haptic?.();
  });

  // ---------- unit picker ----------
  const picker = $("#picker");
  const pickSearch = $("#pick-search");
  const pickList = $("#pick-list");
  let pickSide = 0, pickActive = 0, pickItems = [];

  function openPicker(side) {
    pickSide = side;
    pickSearch.value = "";
    renderPicker();
    document.body.classList.add("picking");
    picker.dataset.side = side ? "to" : "from";
    setTimeout(() => pickSearch.focus(), 50);
  }
  function closePicker() {
    document.body.classList.remove("picking");
    pickSearch.blur();
  }
  function renderPicker() {
    const q = pickSearch.value.trim().toLowerCase();
    const current = state.pairs[state.cat][pickSide];
    pickItems = UNITS[state.cat].filter(u => !q || u[1].toLowerCase().includes(q) || u[2].toLowerCase().includes(q) || u[0].toLowerCase().includes(q));
    pickActive = Math.max(0, pickItems.findIndex(u => u[0] === current));
    pickList.innerHTML = pickItems.map((u, i) => `
      <li data-i="${i}" class="${i === pickActive ? "active" : ""}${u[0] === current ? " current" : ""}" style="--i:${Math.min(i, 12)}">
        ${state.cat === "currency" ? `<span class="p-flag">${flag(u[0])}</span>` : `<span class="p-sym">${u[1]}</span>`}
        <span class="p-name">${u[2]}</span>
        ${state.cat === "currency" ? `<span class="p-code">${u[0]}</span>` : ""}
        <svg class="p-check" viewBox="0 0 12 12"><path d="M2.5 6.5l2.2 2.2 4.8-5"/></svg>
      </li>`).join("");
    const active = pickList.querySelector(".active");
    if (active) active.scrollIntoView({ block: "center" });
  }
  function pick(i) {
    const u = pickItems[i];
    if (!u) return;
    const pair = [...state.pairs[state.cat]];
    if (pair[1 - pickSide] === u[0]) pair[1 - pickSide] = pair[pickSide]; // picking the other side's unit swaps
    pair[pickSide] = u[0];
    state.pairs[state.cat] = pair;
    closePicker();
    shown = null;
    renderUnits();
    compute(false);
    refreshCurrency();
    save();
    window.vaho?.haptic?.();
  }
  $("#from-unit").addEventListener("click", () => openPicker(0));
  $("#to-unit").addEventListener("click", e => { e.stopPropagation(); openPicker(1); });
  $("#pick-close").addEventListener("click", closePicker);
  pickSearch.addEventListener("input", renderPicker);
  pickSearch.addEventListener("keydown", e => {
    if (e.key === "ArrowDown" || e.key === "ArrowUp") {
      e.preventDefault();
      if (!pickItems.length) return;
      pickActive = (pickActive + (e.key === "ArrowDown" ? 1 : -1) + pickItems.length) % pickItems.length;
      pickList.querySelectorAll("li").forEach((li, i) => li.classList.toggle("active", i === pickActive));
      pickList.querySelector(".active")?.scrollIntoView({ block: "nearest" });
    } else if (e.key === "Enter") { e.preventDefault(); pick(pickActive); }
    else if (e.key === "Escape") closePicker();
  });
  pickList.addEventListener("click", e => { const li = e.target.closest("li"); if (li) pick(+li.dataset.i); });
  window.addEventListener("keydown", e => { if (e.key === "Escape" && document.body.classList.contains("picking")) closePicker(); });

  // ---------- boot ----------
  $("#from-label").textContent = S.from;
  $("#to-label").textContent = S.to;
  $("#swap").title = S.swap;
  pickSearch.placeholder = S.search;

  (async () => {
    const saved = await store.get("converter");
    if (saved) {
      if (CATEGORIES.includes(saved.cat)) state.cat = saved.cat;
      for (const c of CATEGORIES) {
        const p = saved.pairs?.[c];
        if (Array.isArray(p) && p.every(id => UNITS[c].some(u => u[0] === id))) state.pairs[c] = p;
      }
      if (typeof saved.input === "string") state.input = saved.input;
    }
    amount.value = state.input;
    renderTabs();
    renderUnits();
    compute(false);
    document.body.classList.add("ready");
    requestAnimationFrame(() => moveInk(false));
    refreshCurrency();
  })();

  window.vaho?.on?.("visible", v => {
    if (v.visible) {
      moveInk(false);
      refreshCurrency();
      setTimeout(() => { amount.focus(); amount.select(); }, 120);
    } else {
      closePicker();
    }
  });
})();
