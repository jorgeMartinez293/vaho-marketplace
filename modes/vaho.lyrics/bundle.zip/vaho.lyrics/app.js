(() => {
  "use strict";

  const lang = (navigator.language || "en").slice(0, 2);
  const STRINGS = {
    en: {
      idle: "Nothing playing", idleSub: "Play a song and its lyrics show up here.",
      loading: "Finding lyrics…", missing: "No lyrics found", missingSub: "LRCLIB doesn't have this one yet.",
      instrumental: "Instrumental", unsynced: "Not synced", retry: "Try again",
      offline: "Couldn't reach LRCLIB", ad: "Advertisement",
      source: "Lyrics from LRCLIB", seek: "Jump here"
    },
    es: {
      idle: "No suena nada", idleSub: "Pon una canción y su letra aparecerá aquí.",
      loading: "Buscando la letra…", missing: "Letra no encontrada", missingSub: "LRCLIB aún no tiene esta canción.",
      instrumental: "Instrumental", unsynced: "Sin sincronizar", retry: "Reintentar",
      offline: "No se pudo conectar con LRCLIB", ad: "Anuncio",
      source: "Letras de LRCLIB", seek: "Saltar aquí"
    }
  };
  const S = STRINGS[lang] || STRINGS.en;

  const $ = s => document.querySelector(s);
  const body = document.body;
  const view = $("#view");
  const list = $("#lines");

  const track = {
    key: "", title: "", artist: "", duration: 0,
    playing: false, position: 0, stampedAt: 0,
    lyrics: null,           // { synced: [{t, text}], plain: [text], instrumental }
    status: "idle",         // idle | loading | synced | plain | instrumental | missing | error
    art: null
  };
  let current = -2;

  // ---------- LRC ----------
  function parseLRC(text) {
    const out = [];
    for (const raw of text.split(/\r?\n/)) {
      const stamps = [...raw.matchAll(/\[(\d{1,3}):(\d{1,2}(?:[.:]\d{1,3})?)\]/g)];
      if (!stamps.length) continue;
      const words = raw.replace(/\[[^\]]*\]/g, "").trim();
      for (const m of stamps) {
        const t = +m[1] * 60 + parseFloat(m[2].replace(":", "."));
        out.push({ t, text: words });
      }
    }
    out.sort((a, b) => a.t - b.t);
    // Blank lines are musical breaks; collapse runs of them.
    const lines = [];
    for (const l of out) {
      if (!l.text && lines.length && !lines[lines.length - 1].text) continue;
      lines.push(l);
    }
    if (lines.length && lines[0].t > 3 && lines[0].text) lines.unshift({ t: 0, text: "" });
    while (lines.length && !lines[lines.length - 1].text) lines.pop();
    return lines;
  }

  // ---------- fetching ----------
  const API = "https://lrclib.net/api";
  const cache = new Map();

  async function lookup(title, artist, duration) {
    const key = keyFor(title, artist);
    if (cache.has(key)) return cache.get(key);
    const stored = await store.get("lrc:" + key);
    if (stored) { cache.set(key, stored); return stored; }

    const q = new URLSearchParams({ track_name: title, artist_name: artist });
    if (duration > 0) q.set("duration", Math.round(duration));
    let hit = null;
    let r = await vaho.net.fetch(`${API}/get?${q}`, { headers: { "Lrclib-Client": "vaho lyrics mode (https://github.com/jorgeMartinez293/vaho)" } });
    if (r.ok) hit = r.json();
    if (!hit || (!hit.syncedLyrics && !hit.plainLyrics && !hit.instrumental)) {
      // Fuzzy fallback: search and prefer synced results with a close duration.
      const sq = new URLSearchParams({ track_name: cleanTitle(title), artist_name: artist });
      r = await vaho.net.fetch(`${API}/search?${sq}`);
      if (r.status >= 500 || r.status === 0) throw new Error("offline");
      const results = r.ok ? r.json() : [];
      const score = x => (x.syncedLyrics ? 0 : 50) + (duration > 0 ? Math.abs((x.duration || 0) - duration) : 0);
      hit = results.filter(x => x.syncedLyrics || x.plainLyrics || x.instrumental).sort((a, b) => score(a) - score(b))[0] || null;
    }
    const value = hit ? {
      synced: hit.syncedLyrics ? parseLRC(hit.syncedLyrics) : null,
      plain: hit.plainLyrics ? hit.plainLyrics.split(/\r?\n/) : null,
      instrumental: !!hit.instrumental
    } : { synced: null, plain: null, instrumental: false, missing: true };
    cache.set(key, value);
    remember(key, value);
    return value;
  }

  function cleanTitle(t) {
    return t.replace(/\s*[([](feat|ft|with|remaster|live|from|prod)[^)\]]*[)\]]/gi, "").replace(/\s+-\s+.*(remaster|version|edit|mix).*$/i, "").trim();
  }
  const keyFor = (t, a) => (a + "—" + t).toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim();

  const store = {
    async get(k) { try { return await vaho.storage.get(k); } catch { return null; } },
    set(k, v) { try { vaho.storage.set(k, v).catch(() => {}); } catch {} },
    remove(k) { try { vaho.storage.remove(k).catch(() => {}); } catch {} }
  };
  async function remember(key, value) {
    if (value.missing) return;
    store.set("lrc:" + key, value);
    const recent = (await store.get("recent")) || [];
    const next = [key, ...recent.filter(k => k !== key)];
    for (const old of next.slice(40)) store.remove("lrc:" + old);
    store.set("recent", next.slice(0, 40));
  }

  // ---------- now playing ----------
  let loadToken = 0;
  function onNowPlaying(np) {
    if (!np || !np.title) {
      if (track.key) setIdle();
      return;
    }
    const key = keyFor(np.title, np.artist || "");
    track.playing = !!np.isPlaying;
    track.position = np.position || 0;
    track.stampedAt = performance.now();
    track.duration = np.duration || 0;
    body.classList.toggle("paused", !track.playing);
    $("#play").classList.toggle("playing", track.playing);
    if (np.artwork !== track.art) setArtwork(np.artwork);

    if (key === track.key) return;
    track.key = key;
    track.title = np.title;
    track.artist = np.artist || "";
    $("#title").textContent = np.title;
    $("#artist").textContent = np.isAd ? S.ad : track.artist;
    body.classList.add("has-track");
    $("#head").classList.remove("swap");
    void $("#head").offsetWidth;
    $("#head").classList.add("swap");
    if (np.isAd) { setStatus("instrumental"); return; }
    load();
  }

  async function load() {
    const token = ++loadToken;
    setStatus("loading");
    try {
      const lyr = await lookup(track.title, track.artist, track.duration);
      if (token !== loadToken) return;
      track.lyrics = lyr;
      if (lyr.synced && lyr.synced.some(l => l.text)) setStatus("synced");
      else if (lyr.plain && lyr.plain.some(Boolean)) setStatus("plain");
      else if (lyr.instrumental) setStatus("instrumental");
      else setStatus("missing");
    } catch {
      if (token === loadToken) setStatus("error");
    }
  }

  function setIdle() {
    track.key = "";
    track.lyrics = null;
    setArtwork(null);
    body.classList.remove("has-track");
    setStatus("idle");
  }

  function setStatus(status) {
    track.status = status;
    body.dataset.status = status;
    current = -2;
    list.innerHTML = "";
    list.style.transform = "";
    const msg = $("#message");
    msg.classList.remove("in");
    void msg.offsetWidth;
    const set = (title, sub, action) => {
      $("#msg-title").textContent = title;
      $("#msg-sub").textContent = sub || "";
      $("#msg-action").hidden = !action;
      msg.classList.add("in");
    };
    switch (status) {
      case "idle": set(S.idle, S.idleSub); break;
      case "loading": set(S.loading, ""); break;
      case "missing": set(S.missing, S.missingSub, true); break;
      case "error": set(S.offline, "", true); break;
      case "instrumental": set(S.instrumental, ""); break;
      case "synced": renderLines(track.lyrics.synced, true); break;
      case "plain": renderLines(track.lyrics.plain.filter((l, i, a) => l || (a[i - 1] && i < a.length - 1)).map(text => ({ text })), false); break;
    }
    $("#badge").textContent = status === "plain" ? S.unsynced : "";
  }

  function renderLines(lines, synced) {
    list.innerHTML = "";
    lines.forEach((l, i) => {
      const li = document.createElement("li");
      li.style.setProperty("--i", Math.min(i, 8));
      if (!l.text) {
        li.className = "line gap";
        li.innerHTML = `<span class="dots"><i></i><i></i><i></i></span>`;
      } else {
        li.className = "line";
        const span = document.createElement("span");
        span.className = "words";
        span.textContent = l.text;
        li.appendChild(span);
      }
      if (synced) {
        li.dataset.t = l.t;
        li.title = S.seek;
      }
      list.appendChild(li);
    });
    list.classList.toggle("synced", synced);
    requestAnimationFrame(() => frame(true));
  }

  // ---------- animation loop ----------
  function now() {
    const t = track.position + (track.playing ? (performance.now() - track.stampedAt) / 1000 : 0);
    return track.duration > 0 ? Math.min(track.duration, t) : t;
  }

  let raf = 0, running = false;
  function frame(force) {
    if (running) raf = requestAnimationFrame(() => frame(false));
    const t = now();
    const pct = track.duration > 0 ? t / track.duration : 0;
    $("#progress").style.transform = `scaleX(${Math.max(0, Math.min(1, pct))})`;

    const items = list.children;
    if (!items.length) return;

    if (track.status === "synced") {
      const lines = track.lyrics.synced;
      // A little lead so the highlight lands as the singer starts, not after.
      const tt = t + 0.25;
      let idx = -1;
      for (let i = 0; i < lines.length; i++) { if (lines[i].t <= tt) idx = i; else break; }
      if (idx !== current || force) {
        current = idx;
        focus(Math.max(0, idx), idx < 0);
      }
      const line = lines[Math.max(0, idx)];
      const next = lines[Math.max(0, idx) + 1];
      const end = next ? next.t : line.t + 5;
      const span = Math.max(0.5, end - line.t);
      const p = idx < 0 ? 0 : Math.max(0, Math.min(1, (tt - line.t) / Math.min(span, Math.max(1.2, span * 0.92))));
      const el = items[Math.max(0, idx)];
      if (el) el.style.setProperty("--p", p.toFixed(4));
    } else if (track.status === "plain") {
      // Unsynced: drift through the text in proportion to the song.
      const idx = Math.floor(pct * items.length * 0.98);
      if (idx !== current || force) { current = idx; focus(idx, false); }
    }
  }

  function focus(idx, before) {
    const items = list.children;
    for (let i = 0; i < items.length; i++) {
      const d = i - idx;
      const el = items[i];
      el.classList.toggle("active", d === 0 && !before);
      el.classList.toggle("past", d < 0);
      el.style.setProperty("--d", Math.min(4, Math.abs(d)));
      if (d !== 0) el.style.removeProperty("--p");
    }
    const target = items[idx];
    if (!target) return;
    const anchor = view.clientHeight * 0.4;
    const y = target.offsetTop + target.offsetHeight / 2 - anchor;
    list.style.transform = `translateY(${-Math.max(0, y)}px)`;
  }

  function start() {
    if (running) return;
    running = true;
    frame(true);
  }
  function stop() {
    running = false;
    cancelAnimationFrame(raf);
  }

  // ---------- artwork & color ----------
  function setArtwork(url) {
    track.art = url;
    const img = $("#art");
    const bg = $("#backdrop");
    img.classList.remove("in");
    if (!url) {
      img.removeAttribute("src");
      bg.style.backgroundImage = "";
      bg.classList.remove("in");
      document.documentElement.style.removeProperty("--tone");
      return;
    }
    const probe = new Image();
    probe.onload = () => {
      if (track.art !== url) return;
      img.src = url;
      img.classList.add("in");
      bg.style.backgroundImage = `url("${url}")`;
      bg.classList.add("in");
      const tone = dominant(probe);
      if (tone) document.documentElement.style.setProperty("--tone", tone);
    };
    probe.src = url;
  }

  // Average of the more saturated pixels, lifted so it reads on black.
  function dominant(img) {
    try {
      const c = document.createElement("canvas");
      c.width = c.height = 24;
      const g = c.getContext("2d");
      g.drawImage(img, 0, 0, 24, 24);
      const d = g.getImageData(0, 0, 24, 24).data;
      let r = 0, gr = 0, b = 0, w = 0;
      for (let i = 0; i < d.length; i += 4) {
        const max = Math.max(d[i], d[i + 1], d[i + 2]), min = Math.min(d[i], d[i + 1], d[i + 2]);
        const sat = max ? (max - min) / max : 0;
        const weight = 0.05 + sat * sat * (max / 255);
        r += d[i] * weight; gr += d[i + 1] * weight; b += d[i + 2] * weight; w += weight;
      }
      r /= w; gr /= w; b /= w;
      const [h, s, l] = toHSL(r, gr, b);
      return `hsl(${Math.round(h)} ${Math.round(Math.min(90, s * 100 + 15))}% ${Math.round(Math.max(62, Math.min(78, l * 100 + 25)))}%)`;
    } catch { return null; }
  }
  function toHSL(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    let h = 0, s = 0;
    const l = (max + min) / 2;
    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      h = max === r ? (g - b) / d + (g < b ? 6 : 0) : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
      h *= 60;
    }
    return [h, s, l];
  }

  // ---------- interactions ----------
  list.addEventListener("click", e => {
    const li = e.target.closest(".line[data-t]");
    if (!li) return;
    const t = Math.max(0, +li.dataset.t - 0.05);
    vaho.media.seek(t).catch(() => {});
    track.position = t;
    track.stampedAt = performance.now();
    li.classList.remove("ping");
    void li.offsetWidth;
    li.classList.add("ping");
    window.vaho?.haptic?.();
  });
  $("#play").addEventListener("click", () => {
    vaho.media.playPause().catch(() => {});
    track.position = now();
    track.stampedAt = performance.now();
    track.playing = !track.playing;
    body.classList.toggle("paused", !track.playing);
    $("#play").classList.toggle("playing", track.playing);
  });
  $("#prev").addEventListener("click", () => vaho.media.previous().catch(() => {}));
  $("#next").addEventListener("click", () => vaho.media.next().catch(() => {}));
  $("#msg-action").addEventListener("click", () => {
    cache.delete(track.key);
    load();
  });
  $("#msg-action").textContent = S.retry;
  $("#source").title = S.source;

  // Wheel peeks through the lyrics without seeking; snaps back after a moment.
  let peekTimer = 0, peek = 0;
  view.addEventListener("wheel", e => {
    if (!list.children.length) return;
    e.preventDefault();
    peek = Math.max(-600, Math.min(600, peek + e.deltaY));
    list.style.translate = `0 ${-peek}px`;
    body.classList.add("peeking");
    clearTimeout(peekTimer);
    peekTimer = setTimeout(() => {
      peek = 0;
      list.style.translate = "";
      body.classList.remove("peeking");
    }, 1400);
  }, { passive: false });

  // ---------- polling ----------
  let poll = 0;
  function refresh() {
    vaho.media.nowPlaying().then(onNowPlaying).catch(() => {});
  }
  function resume() {
    clearInterval(poll);
    refresh();
    poll = setInterval(refresh, 1000);
    start();
  }
  function pause() {
    clearInterval(poll);
    stop();
  }

  vaho.on("nowplaying", onNowPlaying);
  vaho.on("visible", v => (v.visible ? resume() : pause()));

  setStatus("idle");
  resume();
  setTimeout(() => body.classList.add("ready"), 30);
})();
