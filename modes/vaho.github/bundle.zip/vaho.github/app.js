(() => {
  "use strict";

  const lang = (navigator.language || "en").slice(0, 2);
  const STRINGS = {
    en: {
      connect: "Connect GitHub", connectSub: "Paste a classic personal access token with the repo, notifications and read:user scopes.",
      tokenPh: "ghp_…", go: "Connect", create: "Create a token", stored: "Stored only on this Mac.",
      badToken: "GitHub didn't accept that token.", offline: "Can't reach GitHub right now.",
      prs: "Pull requests", reviews: "Reviews", inbox: "Inbox",
      emptyPrs: "No open pull requests", emptyReviews: "Nobody's waiting on you", emptyInbox: "Inbox zero",
      emptySub: "Enjoy it.", inboxScope: "Inbox needs a classic token with the notifications scope.",
      contributions: "{0} contributions in the last {1} months", contribLabel: "contributions · {0} mo", today: "today",
      contribOne: "{0} contribution", contribMany: "{0} contributions", none: "No contributions",
      approved: "Approved", changes: "Changes", draft: "Draft", review: "Review",
      refresh: "Refresh", signOut: "Disconnect", updated: "Updated {0}", now: "just now",
      markRead: "Mark as read", open: "Open on GitHub",
      reason: { review_requested: "review", mention: "mention", assign: "assigned", author: "author", comment: "comment", ci_activity: "CI", state_change: "state", subscribed: "watching", team_mention: "team", security_alert: "security", manual: "subscribed", invitation: "invite" }
    },
    es: {
      connect: "Conecta GitHub", connectSub: "Pega un token personal (classic) con los permisos repo, notifications y read:user.",
      tokenPh: "ghp_…", go: "Conectar", create: "Crear un token", stored: "Se guarda solo en este Mac.",
      badToken: "GitHub no ha aceptado ese token.", offline: "No se puede conectar con GitHub.",
      prs: "Pull requests", reviews: "Revisiones", inbox: "Bandeja",
      emptyPrs: "Sin pull requests abiertas", emptyReviews: "Nadie te está esperando", emptyInbox: "Bandeja vacía",
      emptySub: "Disfrútalo.", inboxScope: "La bandeja necesita un token classic con el permiso notifications.",
      contributions: "{0} contribuciones en los últimos {1} meses", contribLabel: "contribuciones · {0} m", today: "hoy",
      contribOne: "{0} contribución", contribMany: "{0} contribuciones", none: "Sin contribuciones",
      approved: "Aprobada", changes: "Cambios", draft: "Borrador", review: "Revisión",
      refresh: "Actualizar", signOut: "Desconectar", updated: "Actualizado {0}", now: "ahora",
      markRead: "Marcar como leída", open: "Abrir en GitHub",
      reason: { review_requested: "revisión", mention: "mención", assign: "asignada", author: "autor", comment: "comentario", ci_activity: "CI", state_change: "estado", subscribed: "siguiendo", team_mention: "equipo", security_alert: "seguridad", manual: "suscrito", invitation: "invitación" }
    }
  };
  const S = STRINGS[lang] || STRINGS.en;
  const fmt = (s, ...a) => s.replace(/\{(\d)\}/g, (_, i) => a[i]);

  const API = "https://api.github.com";
  const WEEKS = 26;
  const $ = s => document.querySelector(s);
  const body = document.body;

  const store = {
    async get(k) { try { return await vaho.storage.get(k); } catch { return null; } },
    set(k, v) { try { return vaho.storage.set(k, v).catch(() => {}); } catch {} },
    remove(k) { try { return vaho.storage.remove(k).catch(() => {}); } catch {} }
  };

  const state = {
    token: null,
    tab: "prs",
    data: null,          // { viewer, calendar, prs, reviews, inbox, inboxError, fetchedAt }
    avatar: null,
    loading: false
  };

  // ---------- API ----------
  async function gh(path, opts = {}) {
    const r = await vaho.net.fetch(API + path, {
      method: opts.method || "GET",
      headers: {
        Authorization: "Bearer " + state.token,
        Accept: "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        ...(opts.body ? { "Content-Type": "application/json" } : {})
      },
      body: opts.body ? JSON.stringify(opts.body) : null
    });
    if (r.status === 401) throw Object.assign(new Error("auth"), { code: 401 });
    return r;
  }

  const PR_FIELDS = `
    ... on PullRequest {
      id title url number isDraft updatedAt reviewDecision
      repository { nameWithOwner }
      author { login }
      commits(last: 1) { nodes { commit { statusCheckRollup { state } } } }
    }`;

  async function fetchAll() {
    const from = new Date(Date.now() - WEEKS * 7 * 864e5);
    from.setUTCHours(0, 0, 0, 0);
    let login = state.data?.viewer?.login;
    if (!login) {
      const r = await gh("/user");
      if (!r.ok) throw new Error("user " + r.status);
      login = r.json().login;
    }
    const q = `query($from: DateTime!, $mine: String!, $asked: String!) {
      viewer {
        login name avatarUrl(size: 80)
        contributionsCollection(from: $from) {
          contributionCalendar { totalContributions weeks { contributionDays { date contributionCount contributionLevel } } }
        }
      }
      prs: search(query: $mine, type: ISSUE, first: 20) { issueCount nodes { ${PR_FIELDS} } }
      reviews: search(query: $asked, type: ISSUE, first: 20) { issueCount nodes { ${PR_FIELDS} } }
    }`;
    const variables = {
      from: from.toISOString(),
      mine: `is:open is:pr author:${login} archived:false sort:updated-desc`,
      asked: `is:open is:pr review-requested:${login} archived:false sort:updated-desc`
    };
    const [gql, notes] = await Promise.all([
      gh("/graphql", { method: "POST", body: { query: q, variables } }),
      gh("/notifications?per_page=30").catch(e => e)
    ]);
    if (!gql.ok) throw new Error("graphql " + gql.status);
    const j = gql.json();
    if (j.errors && !j.data) throw new Error(j.errors[0].message);
    const v = j.data.viewer;
    const pr = n => ({
      id: n.id, title: n.title, url: n.url, number: n.number, draft: n.isDraft, updated: n.updatedAt,
      decision: n.reviewDecision, repo: n.repository.nameWithOwner, author: n.author?.login,
      ci: n.commits?.nodes?.[0]?.commit?.statusCheckRollup?.state || null
    });
    let inbox = [], inboxError = null;
    if (notes instanceof Error || !notes.ok) {
      inboxError = notes instanceof Error ? "offline" : notes.status === 403 || notes.status === 404 ? "scope" : "offline";
    } else {
      inbox = notes.json().map(n => ({
        id: n.id, title: n.subject.title, type: n.subject.type, reason: n.reason,
        repo: n.repository.full_name, updated: n.updated_at, unread: n.unread,
        url: htmlURL(n)
      }));
    }
    return {
      viewer: { login: v.login, name: v.name, avatarUrl: v.avatarUrl },
      calendar: {
        total: v.contributionsCollection.contributionCalendar.totalContributions,
        weeks: v.contributionsCollection.contributionCalendar.weeks.map(w => w.contributionDays.map(d => [d.date, d.contributionCount, d.contributionLevel]))
      },
      prs: { count: j.data.prs.issueCount, items: j.data.prs.nodes.filter(n => n.id).map(pr) },
      reviews: { count: j.data.reviews.issueCount, items: j.data.reviews.nodes.filter(n => n.id).map(pr) },
      inbox, inboxError,
      fetchedAt: Date.now()
    };
  }

  function htmlURL(n) {
    const api = n.subject.url || n.subject.latest_comment_url;
    const repoURL = n.repository.html_url;
    if (!api) return repoURL + (n.subject.type === "Discussion" ? "/discussions" : "");
    const m = /\/repos\/[^/]+\/[^/]+\/(pulls|issues|releases|commits)\/([^/]+)/.exec(api);
    if (!m) return repoURL;
    const kind = { pulls: "pull", issues: "issues", releases: "releases", commits: "commit" }[m[1]];
    return m[1] === "releases" ? repoURL + "/releases" : `${repoURL}/${kind}/${m[2]}`;
  }

  async function loadAvatar(url) {
    if (!url) return null;
    const cached = await store.get("avatar");
    if (cached && cached.url === url) return cached.data;
    try {
      const r = await vaho.net.fetch(url);
      if (!r.ok) return null;
      const type = (r.headers["Content-Type"] || r.headers["content-type"] || "image/png").split(";")[0];
      const data = `data:${type};base64,${r.body}`;
      store.set("avatar", { url, data });
      return data;
    } catch { return null; }
  }

  // ---------- flows ----------
  async function refresh(manual) {
    if (!state.token || state.loading) return;
    state.loading = true;
    body.classList.add("loading");
    const btn = $("#refresh");
    btn.classList.remove("spin");
    void btn.offsetWidth;
    btn.classList.add("spin");
    try {
      const data = await fetchAll();
      state.data = data;
      store.set("cache", data);
      render(true);
      const avatar = await loadAvatar(data.viewer.avatarUrl);
      if (avatar && avatar !== state.avatar) { state.avatar = avatar; renderHeader(); }
      body.classList.remove("offline");
      if (manual) window.vaho?.haptic?.();
    } catch (e) {
      if (e.code === 401) {
        await signOut();
        showSetupError(S.badToken);
      } else {
        body.classList.add("offline");
        $("#updated").textContent = S.offline;
      }
    } finally {
      state.loading = false;
      body.classList.remove("loading");
    }
  }

  async function connect(token) {
    token = token.trim();
    if (!token) return;
    const btn = $("#connect");
    btn.classList.add("busy");
    btn.disabled = true;
    state.token = token;
    try {
      const r = await gh("/user");
      if (!r.ok) throw Object.assign(new Error(), { code: r.status });
      await store.set("token", token);
      state.data = null;
      body.classList.remove("setup");
      body.classList.add("connected");
      $("#token").value = "";
      await refresh();
    } catch (e) {
      state.token = null;
      showSetupError(e.code === 401 ? S.badToken : S.offline);
    } finally {
      btn.classList.remove("busy");
      btn.disabled = false;
    }
  }

  function showSetupError(msg) {
    const el = $("#setup-error");
    el.textContent = msg;
    const card = $("#setup");
    card.classList.remove("shake");
    void card.offsetWidth;
    card.classList.add("shake");
  }

  async function signOut() {
    state.token = null;
    state.data = null;
    state.avatar = null;
    await Promise.all([store.remove("token"), store.remove("cache"), store.remove("avatar")]);
    body.classList.remove("connected", "menu-open");
    body.classList.add("setup");
    resize();
  }

  // ---------- rendering ----------
  function render(fresh) {
    if (!state.data) return;
    renderHeader();
    renderHeatmap(fresh);
    renderTabs();
    renderList(fresh);
    tickUpdated();
  }

  function renderHeader() {
    const v = state.data.viewer;
    $("#name").textContent = v.name || v.login;
    $("#login").textContent = "@" + v.login;
    const img = $("#avatar");
    if (state.avatar) { img.src = state.avatar; img.classList.add("in"); }
  }

  function renderHeatmap(fresh) {
    const cal = state.data.calendar;
    const grid = $("#heat");
    const weeks = cal.weeks.slice(-WEEKS);
    const todayKey = new Date().toISOString().slice(0, 10);
    const levels = { NONE: 0, FIRST_QUARTILE: 1, SECOND_QUARTILE: 2, THIRD_QUARTILE: 3, FOURTH_QUARTILE: 4 };
    let html = "";
    weeks.forEach((w, wi) => {
      html += `<div class="wk" style="--w:${wi}">`;
      // Pad the first (partial) week so days line up by weekday.
      if (wi === 0) for (let k = 0; k < 7 - w.length; k++) html += `<i class="pad"></i>`;
      for (const [date, count, level] of w) {
        const lv = levels[level] ?? 0;
        html += `<i class="c l${lv}${date === todayKey ? " today" : ""}" data-d="${date}" data-n="${count}"></i>`;
      }
      html += `</div>`;
    });
    grid.innerHTML = html;
    grid.classList.toggle("wave", !!fresh);
    const months = Math.round(WEEKS / 4.35);
    $("#heat-total").textContent = cal.total.toLocaleString(lang);
    $("#heat-label").textContent = fmt(S.contribLabel, months);
    $("#heat-wrap").title = fmt(S.contributions, cal.total.toLocaleString(lang), months);
    const streak = streakText(weeks);
    $("#streak-n").textContent = streak;
    $("#streak").hidden = !streak;
  }

  function streakText(weeks) {
    const days = weeks.flat();
    let i = days.length - 1;
    if (days[i] && days[i][1] === 0) i--; // today not counted yet is fine
    let n = 0;
    while (i >= 0 && days[i][1] > 0) { n++; i--; }
    return n > 1 ? String(n) : "";
  }

  function renderTabs() {
    const d = state.data;
    const counts = { prs: d.prs.count, reviews: d.reviews.count, inbox: d.inbox.filter(n => n.unread).length };
    for (const t of ["prs", "reviews", "inbox"]) {
      const el = document.querySelector(`.tab[data-tab="${t}"]`);
      el.classList.toggle("on", t === state.tab);
      const badge = el.querySelector(".count");
      const prev = badge.textContent;
      badge.textContent = counts[t] || "";
      if (prev !== badge.textContent && counts[t]) { badge.classList.remove("bump"); void badge.offsetWidth; badge.classList.add("bump"); }
      el.classList.toggle("hot", t === "reviews" && counts[t] > 0);
    }
    moveInk();
  }

  function moveInk() {
    const on = document.querySelector(".tab.on");
    const ink = $("#ink");
    if (!on) return;
    ink.style.width = on.offsetWidth + "px";
    ink.style.transform = `translateX(${on.offsetLeft}px)`;
  }

  function renderList(fresh) {
    const d = state.data;
    const ul = $("#list");
    const empty = $("#empty");
    let items = [];
    if (state.tab === "prs") items = d.prs.items.map((p, i) => prItem(p, false, i));
    else if (state.tab === "reviews") items = d.reviews.items.map((p, i) => prItem(p, true, i));
    else items = d.inbox.map(noteItem);

    ul.innerHTML = items.join("");
    ul.classList.toggle("fresh", !!fresh);
    const isEmpty = !items.length;
    empty.hidden = !isEmpty;
    if (isEmpty) {
      const scope = state.tab === "inbox" && d.inboxError === "scope";
      $("#empty-title").textContent = scope ? S.inbox : { prs: S.emptyPrs, reviews: S.emptyReviews, inbox: S.emptyInbox }[state.tab];
      $("#empty-sub").textContent = scope ? S.inboxScope : S.emptySub;
      empty.classList.toggle("warn", scope);
      empty.classList.remove("pop");
      void empty.offsetWidth;
      empty.classList.add("pop");
    }
  }

  const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);

  function prItem(p, review, i) {
    const ci = { SUCCESS: "ok", FAILURE: "fail", ERROR: "fail", PENDING: "wait", EXPECTED: "wait" }[p.ci] || "";
    const chip = p.draft ? `<span class="chip draft">${S.draft}</span>`
      : p.decision === "APPROVED" ? `<span class="chip ok">${S.approved}</span>`
      : p.decision === "CHANGES_REQUESTED" ? `<span class="chip fail">${S.changes}</span>`
      : review ? `<span class="chip ask">${S.review}</span>` : "";
    return `<li class="item" data-url="${esc(p.url)}" style="--i:${Math.min(i, 8)}">
      <span class="ico pr${p.draft ? " draft" : ""}">${ICON.pr}${ci ? `<i class="ci ${ci}"></i>` : ""}</span>
      <span class="txt">
        <span class="t">${esc(p.title)}</span>
        <span class="s">${esc(p.repo)} <b>#${p.number}</b>${review && p.author ? ` · ${esc(p.author)}` : ""} · ${ago(p.updated)}</span>
      </span>
      ${chip}
      <span class="go">${ICON.arrow}</span>
    </li>`;
  }

  function noteItem(n, i) {
    const icon = { PullRequest: ICON.pr, Issue: ICON.issue, Release: ICON.tag, Discussion: ICON.chat, CheckSuite: ICON.check }[n.type] || ICON.bell;
    return `<li class="item note${n.unread ? " unread" : ""}" data-url="${esc(n.url)}" data-thread="${esc(n.id)}" style="--i:${Math.min(i, 8)}">
      <span class="ico">${icon}</span>
      <span class="txt">
        <span class="t">${esc(n.title)}</span>
        <span class="s">${esc(n.repo)} · ${esc(S.reason[n.reason] || n.reason)} · ${ago(n.updated)}</span>
      </span>
      ${n.unread ? `<button class="read" title="${S.markRead}">${ICON.check}</button>` : ""}
      <span class="go">${ICON.arrow}</span>
    </li>`;
  }

  function ago(iso) {
    const s = (Date.now() - new Date(iso).getTime()) / 1000;
    const rtf = new Intl.RelativeTimeFormat(lang, { numeric: "auto", style: "narrow" });
    if (s < 60) return S.now;
    if (s < 3600) return rtf.format(-Math.round(s / 60), "minute");
    if (s < 86400) return rtf.format(-Math.round(s / 3600), "hour");
    if (s < 86400 * 30) return rtf.format(-Math.round(s / 86400), "day");
    return rtf.format(-Math.round(s / (86400 * 30)), "month");
  }

  function tickUpdated() {
    if (!state.data || body.classList.contains("offline")) return;
    $("#updated").textContent = fmt(S.updated, ago(new Date(state.data.fetchedAt).toISOString()));
  }

  // ---------- icons (drawn for this mode) ----------
  const ICON = {
    pr: `<svg viewBox="0 0 16 16"><circle cx="4" cy="3.5" r="1.8"/><circle cx="4" cy="12.5" r="1.8"/><circle cx="12" cy="12.5" r="1.8"/><path d="M4 5.3v5.4M12 10.7V6.5a2 2 0 0 0-2-2H7.5M9 3l-1.5 1.5L9 6"/></svg>`,
    issue: `<svg viewBox="0 0 16 16"><circle cx="8" cy="8" r="5.8"/><circle cx="8" cy="8" r="1.2" class="fill"/></svg>`,
    tag: `<svg viewBox="0 0 16 16"><path d="M2.5 2.5h5l6 6-5 5-6-6z"/><circle cx="5.3" cy="5.3" r="1" class="fill"/></svg>`,
    chat: `<svg viewBox="0 0 16 16"><path d="M2.5 3.5h11v7h-6l-3 2.5v-2.5h-2z"/></svg>`,
    check: `<svg viewBox="0 0 16 16"><path d="M3.5 8.5l3 3 6-7"/></svg>`,
    bell: `<svg viewBox="0 0 16 16"><path d="M4 11V7a4 4 0 0 1 8 0v4l1 1.5H3zM6.5 14h3"/></svg>`,
    arrow: `<svg viewBox="0 0 16 16"><path d="M5 11l6-6M6 5h5v5"/></svg>`
  };

  // ---------- interactions ----------
  $("#tabs").addEventListener("click", e => {
    const t = e.target.closest(".tab");
    if (!t || t.dataset.tab === state.tab || !state.data) return;
    state.tab = t.dataset.tab;
    store.set("tab", state.tab);
    renderTabs();
    renderList(true);
    window.vaho?.haptic?.();
  });

  $("#list").addEventListener("click", e => {
    const li = e.target.closest(".item");
    if (!li) return;
    const read = e.target.closest(".read");
    const thread = li.dataset.thread;
    if (thread && li.classList.contains("unread")) {
      li.classList.remove("unread");
      li.querySelector(".read")?.remove();
      const n = state.data.inbox.find(x => x.id === thread);
      if (n) n.unread = false;
      renderTabs();
      gh(`/notifications/threads/${thread}`, { method: "PATCH" }).catch(() => {});
    }
    if (read) { window.vaho?.haptic?.(); return; }
    li.classList.add("opening");
    vaho.openURL(li.dataset.url).catch(() => {});
  });

  // Heatmap tooltip.
  const tip = $("#tip");
  $("#heat").addEventListener("pointerover", e => {
    const c = e.target.closest(".c");
    if (!c) return;
    const n = +c.dataset.n;
    const date = new Date(c.dataset.d + "T12:00:00");
    const day = c.classList.contains("today") ? S.today : new Intl.DateTimeFormat(lang, { month: "short", day: "numeric" }).format(date);
    tip.innerHTML = `<b>${n ? fmt(n === 1 ? S.contribOne : S.contribMany, n) : S.none}</b> · ${day}`;
    const r = c.getBoundingClientRect();
    const host = $("#heat-wrap").getBoundingClientRect();
    const x = r.left - host.left + r.width / 2;
    tip.style.setProperty("--x", x + "px");
    tip.style.setProperty("--y", r.top - host.top + "px");
    tip.classList.add("on");
    const w = tip.offsetWidth;
    tip.style.setProperty("--shift", Math.max(0, Math.min(host.width - w, x - w / 2)) + "px");
  });
  $("#heat").addEventListener("pointerleave", () => tip.classList.remove("on"));
  $("#heat").addEventListener("click", e => {
    const c = e.target.closest(".c");
    if (!c || !state.data) return;
    vaho.openURL(`https://github.com/${state.data.viewer.login}?tab=overview&from=${c.dataset.d}&to=${c.dataset.d}`).catch(() => {});
  });

  $("#refresh").addEventListener("click", () => refresh(true));
  $("#profile").addEventListener("click", () => body.classList.toggle("menu-open"));
  $("#open-profile").addEventListener("click", () => {
    body.classList.remove("menu-open");
    if (state.data) vaho.openURL(`https://github.com/${state.data.viewer.login}`).catch(() => {});
  });
  $("#sign-out").addEventListener("click", () => signOut());
  document.addEventListener("click", e => {
    if (!e.target.closest("#profile, .menu")) body.classList.remove("menu-open");
  });

  $("#setup-form").addEventListener("submit", e => {
    e.preventDefault();
    connect($("#token").value);
  });
  $("#token").addEventListener("input", () => {
    $("#setup-error").textContent = "";
    $("#connect").classList.toggle("ready", $("#token").value.trim().length > 20);
  });
  $("#create").addEventListener("click", () => {
    vaho.openURL("https://github.com/settings/tokens/new?scopes=repo,notifications,read:user&description=vaho%20notch").catch(() => {});
  });

  function resize() {
    vaho.notch.setHeight(body.classList.contains("setup") ? 236 : null).catch(() => {});
  }

  // ---------- boot ----------
  const texts = {
    "#setup-title": S.connect, "#setup-sub": S.connectSub, "#connect-label": S.go,
    "#create-label": S.create, "#stored": S.stored,
    "#tab-prs": S.prs, "#tab-reviews": S.reviews, "#tab-inbox": S.inbox,
    "#open-profile-label": S.open, "#sign-out-label": S.signOut
  };
  for (const [sel, txt] of Object.entries(texts)) $(sel).textContent = txt;
  $("#token").placeholder = S.tokenPh;
  $("#refresh").title = S.refresh;

  let timer = 0, clock = 0;
  function schedule() {
    clearInterval(timer);
    clearInterval(clock);
    timer = setInterval(() => refresh(false), 3 * 60e3);
    clock = setInterval(tickUpdated, 30e3);
  }

  (async () => {
    const [token, cache, avatar, tab] = await Promise.all([store.get("token"), store.get("cache"), store.get("avatar"), store.get("tab")]);
    if (tab) state.tab = tab;
    if (token) {
      state.token = token;
      body.classList.add("connected");
      if (cache) {
        state.data = cache;
        state.avatar = avatar?.data || null;
        render(true);
      }
      if (!cache || Date.now() - cache.fetchedAt > 60e3) refresh();
      schedule();
    } else {
      body.classList.add("setup");
    }
    resize();
    setTimeout(() => body.classList.add("ready"), 30);
  })();

  vaho.on("visible", v => {
    if (!v.visible) {
      clearInterval(timer);
      clearInterval(clock);
      body.classList.remove("menu-open");
      return;
    }
    requestAnimationFrame(moveInk);
    if (state.token) {
      schedule();
      if (!state.data || Date.now() - state.data.fetchedAt > 60e3) refresh();
      tickUpdated();
    }
  });
})();
