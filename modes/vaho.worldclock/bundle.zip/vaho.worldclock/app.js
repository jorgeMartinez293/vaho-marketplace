(() => {
  "use strict";

  // ---------- strings ----------
  const STRINGS = {
    en: {
      today: "Today", tomorrow: "Tomorrow", yesterday: "Yesterday",
      same: "Same time", local: "You are here",
      add: "Add city", search: "Search a city or time zone",
      none: "No matches", hint: "Hover the strips to compare times",
      pinned: "Pinned", reset: "Now",
      inFuture: "in {0}", inPast: "{0} ago", remove: "Remove",
      h12: "12-hour clock", h24: "24-hour clock"
    },
    es: {
      today: "Hoy", tomorrow: "Mañana", yesterday: "Ayer",
      same: "Misma hora", local: "Estás aquí",
      add: "Añadir ciudad", search: "Busca una ciudad o zona horaria",
      none: "Sin resultados", hint: "Pasa el ratón por las franjas para comparar horas",
      pinned: "Fijado", reset: "Ahora",
      inFuture: "dentro de {0}", inPast: "hace {0}", remove: "Quitar",
      h12: "Reloj de 12 horas", h24: "Reloj de 24 horas"
    }
  };
  const lang = (navigator.language || "en").slice(0, 2);
  const S = STRINGS[lang] || STRINGS.en;
  const fmt = (s, ...a) => s.replace(/\{(\d)\}/g, (_, i) => a[i]);

  // ---------- time zone math ----------
  const partsCache = new Map();
  function partsFormatter(tz) {
    if (!partsCache.has(tz)) {
      partsCache.set(tz, new Intl.DateTimeFormat("en-US", {
        timeZone: tz, hourCycle: "h23",
        year: "numeric", month: "numeric", day: "numeric",
        hour: "numeric", minute: "numeric", second: "numeric", weekday: "short"
      }));
    }
    return partsCache.get(tz);
  }
  function zoned(tz, ms) {
    const p = {};
    for (const { type, value } of partsFormatter(tz).formatToParts(ms)) p[type] = value;
    const asUTC = Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour % 24, +p.minute, +p.second);
    return {
      y: +p.year, mo: +p.month, d: +p.day, h: +p.hour % 24, m: +p.minute, s: +p.second,
      offset: Math.round((asUTC - Math.floor(ms / 1000) * 1000) / 60000),
      dayKey: +p.year * 10000 + +p.month * 100 + +p.day
    };
  }
  const shortName = new Map();
  function zoneAbbrev(tz, ms) {
    const key = tz;
    if (!shortName.has(key)) shortName.set(key, new Intl.DateTimeFormat(lang, { timeZone: tz, timeZoneName: "short" }));
    const part = shortName.get(key).formatToParts(ms).find(p => p.type === "timeZoneName");
    return part ? part.value : "";
  }
  const weekdayFmt = new Map();
  function weekday(tz, ms) {
    if (!weekdayFmt.has(tz)) weekdayFmt.set(tz, new Intl.DateTimeFormat(lang, { timeZone: tz, weekday: "short" }));
    return weekdayFmt.get(tz).format(ms).replace(".", "");
  }
  function validZone(tz) {
    try { new Intl.DateTimeFormat("en", { timeZone: tz }); return true; } catch { return false; }
  }

  // ---------- sky ----------
  // Hour → color. Night indigo, a pink/amber dawn, clear day blue, a warm dusk.
  const SKY = [
    [0, "#0a0f24"], [4.5, "#141a3a"], [5.6, "#3b2a5e"], [6.3, "#c86b86"], [7.0, "#f2a863"],
    [8.2, "#7fb8f0"], [12, "#8cc9ff"], [16.5, "#78b3ee"], [18.2, "#f39a5a"], [19.1, "#b8567f"],
    [20.2, "#35306a"], [21.5, "#141a3a"], [24, "#0a0f24"]
  ].map(([h, c]) => [h, [1, 3, 5].map(i => parseInt(c.slice(i, i + 2), 16))]);
  function sky(h) {
    for (let i = 1; i < SKY.length; i++) {
      if (h <= SKY[i][0]) {
        const [h0, c0] = SKY[i - 1], [h1, c1] = SKY[i];
        const k = (h - h0) / (h1 - h0);
        const e = k * k * (3 - 2 * k);
        return `rgb(${c0.map((v, j) => Math.round(v + (c1[j] - v) * e)).join(",")})`;
      }
    }
    return "#0a0f24";
  }

  // The strip shows 24 hours: 6 behind "now", 18 ahead.
  const BEHIND = 6 * 3600e3, SPAN = 24 * 3600e3;

  // ---------- state ----------
  const localTZ = Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";
  const state = {
    cities: [],          // [{ name, tz }]
    h12: null,           // null = locale default
    scrub: null,         // ms offset from now while hovering / pinned
    pinned: false,
    windowStart: 0
  };
  const defaultH12 = new Intl.DateTimeFormat(lang, { hour: "numeric" }).resolvedOptions().hourCycle?.startsWith("h1") ?? false;
  const use12 = () => (state.h12 == null ? defaultH12 : state.h12);

  function cityFor(tz) {
    const hit = window.CITIES.find(c => c[2] === tz);
    if (hit) return hit[0];
    return tz.split("/").pop().replace(/_/g, " ");
  }

  // ---------- DOM ----------
  const $ = s => document.querySelector(s);
  const rowsEl = $("#rows");
  const nowLine = $("#now-line");
  const scrubLine = $("#scrub-line");
  const scrubPill = $("#scrub-pill");
  const footNote = $("#foot-note");

  function allRows() {
    return [{ name: cityFor(localTZ), tz: localTZ, local: true }, ...state.cities];
  }

  function build(animate) {
    rowsEl.querySelectorAll(".row").forEach(r => r.remove());
    allRows().forEach((c, i) => {
      const row = document.createElement("div");
      row.className = "row" + (c.local ? " local" : "") + (animate === i ? " enter" : "");
      row.style.setProperty("--i", i);
      row.innerHTML = `
        ${c.local ? "" : `<button class="remove" title="${S.remove}" aria-label="${S.remove}"><svg viewBox="0 0 12 12"><path d="M3.5 3.5l5 5M8.5 3.5l-5 5"/></svg></button>`}
        <div class="place">
          <div class="name"><span class="label"></span>${c.local ? `<svg class="pin" viewBox="0 0 12 12" aria-label="${S.local}"><path d="M10.6 1.4L1.5 5.3l3.9 1.3 1.3 3.9z"/></svg>` : ""}</div>
          <div class="meta"></div>
        </div>
        <div class="strip"><div class="sky"></div><div class="marks"></div></div>
        <div class="time" title="${use12() ? S.h24 : S.h12}"><span class="hm"></span><span class="ap"></span></div>`;
      row.querySelector(".label").textContent = c.name;
      row._city = c;
      const rm = row.querySelector(".remove");
      if (rm) rm.addEventListener("click", () => removeCity(i - 1, row));
      row.querySelector(".time").addEventListener("click", toggleClock);
      rowsEl.insertBefore(row, nowLine);
    });
    resize();
    paintStrips(true);
    tick(true);
  }

  function paintStrips() {
    const now = Date.now();
    state.windowStart = now - BEHIND;
    const localNow = zoned(localTZ, now);
    rowsEl.querySelectorAll(".row").forEach(row => {
      const tz = row._city.tz;
      const stops = [];
      const marks = [];
      const N = 48;
      let prevDay = null;
      for (let k = 0; k <= N; k++) {
        const ms = state.windowStart + (SPAN * k) / N;
        const z = zoned(tz, ms);
        stops.push(`${sky(z.h + z.m / 60)} ${((k / N) * 100).toFixed(2)}%`);
        if (prevDay !== null && z.dayKey !== prevDay) {
          // Find the local midnight between the previous sample and this one.
          const minutesIn = z.h * 60 + z.m;
          const at = ms - minutesIn * 60000;
          marks.push({ x: (at - state.windowStart) / SPAN, label: weekday(tz, ms) });
        }
        prevDay = z.dayKey;
      }
      row.querySelector(".sky").style.background = `linear-gradient(90deg, ${stops.join(",")})`;
      row.querySelector(".marks").innerHTML = marks
        .map(m => `<span class="mark${m.x > 0.86 ? " edge" : ""}" style="left:${(m.x * 100).toFixed(2)}%"><i>${m.label}</i></span>`).join("");
    });
    const strip = rowsEl.querySelector(".strip");
    if (strip) {
      const r = strip.getBoundingClientRect(), p = rowsEl.getBoundingClientRect();
      rowsEl.style.setProperty("--strip-left", r.left - p.left + "px");
      rowsEl.style.setProperty("--strip-width", r.width + "px");
      nowLine.style.left = r.left - p.left + (BEHIND / SPAN) * r.width + "px";
    }
    void localNow;
  }

  let lastSecond = -1;
  function tick(force) {
    const now = Date.now();
    const at = now + (state.scrub || 0);
    const sec = Math.floor(now / 1000);
    if (!force && sec === lastSecond && state.scrub == null) return;
    lastSecond = sec;
    document.body.classList.toggle("scrubbing", state.scrub != null);
    const here = zoned(localTZ, at);
    const today = zoned(localTZ, now);
    rowsEl.querySelectorAll(".row").forEach(row => {
      const c = row._city;
      const z = c.local ? here : zoned(c.tz, at);
      const h = use12() ? ((z.h + 11) % 12) + 1 : z.h;
      const hm = (use12() ? String(h) : String(h).padStart(2, "0")) + ":" + String(z.m).padStart(2, "0");
      setRolling(row.querySelector(".hm"), hm);
      row.querySelector(".ap").textContent = use12() ? (z.h < 12 ? "AM" : "PM") : "";
      const isDay = z.h >= 7 && z.h < 19;
      row.classList.toggle("night", !isDay);

      let meta;
      const dayDiff = Math.round((Date.UTC(z.y, z.mo - 1, z.d) - Date.UTC(today.y, today.mo - 1, today.d)) / 864e5);
      const dayWord = dayDiff === 0 ? S.today : dayDiff === 1 ? S.tomorrow : dayDiff === -1 ? S.yesterday : weekday(c.tz, at);
      if (c.local) {
        meta = `${dayWord} · ${zoneAbbrev(c.tz, at)}`;
      } else {
        const diff = z.offset - here.offset;
        meta = `${dayWord} · ${diff === 0 ? S.same : formatOffset(diff)}`;
      }
      const metaEl = row.querySelector(".meta");
      if (metaEl.textContent !== meta) metaEl.textContent = meta;
    });
    if (sec % 60 === 0 || force) paintStrips();
  }

  function formatOffset(min) {
    const sign = min > 0 ? "+" : "−";
    const a = Math.abs(min);
    const h = Math.floor(a / 60), m = a % 60;
    return `${sign}${h}h${m ? " " + m + "m" : ""}`;
  }

  function formatSpan(ms) {
    const a = Math.round(Math.abs(ms) / 60000);
    const h = Math.floor(a / 60), m = a % 60;
    const txt = h && m ? `${h}h ${m}m` : h ? `${h}h` : `${m}m`;
    return ms >= 0 ? fmt(S.inFuture, txt) : fmt(S.inPast, txt);
  }

  // Digits that roll when they change.
  function setRolling(el, text) {
    if (el.dataset.v === text) return;
    const old = el.dataset.v || "";
    el.dataset.v = text;
    const chars = [...text];
    if (el.children.length !== chars.length) {
      el.innerHTML = chars.map(ch => `<span class="d${ch === ":" ? " colon" : ""}">${ch}</span>`).join("");
      return;
    }
    const scrubbing = state.scrub != null;
    chars.forEach((ch, i) => {
      const span = el.children[i];
      if (old[i] === ch) return;
      span.textContent = ch;
      span.classList.remove("roll", "roll-fast");
      void span.offsetWidth;
      span.classList.add(scrubbing ? "roll-fast" : "roll");
    });
  }

  // ---------- scrubbing ----------
  function scrubFromEvent(e) {
    const r = rowsEl.querySelector(".strip").getBoundingClientRect();
    const x = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
    const ms = state.windowStart + x * SPAN;
    const snapped = Math.round(ms / 900000) * 900000;
    setScrub(snapped - Date.now());
  }

  function setScrub(offset) {
    const clamped = offset == null ? null : Math.max(-BEHIND, Math.min(SPAN - BEHIND, offset));
    state.scrub = clamped;
    if (clamped == null) {
      scrubLine.classList.remove("on");
      scrubPill.classList.remove("on");
      footNote.textContent = S.hint;
      document.body.classList.remove("pinned");
      state.pinned = false;
    } else {
      const r = rowsEl.querySelector(".strip").getBoundingClientRect(), p = rowsEl.getBoundingClientRect();
      const x = r.left - p.left + ((clamped + Date.now() - state.windowStart) / SPAN) * r.width;
      scrubLine.style.transform = `translateX(${x}px)`;
      scrubLine.classList.add("on");
      scrubPill.textContent = Math.abs(clamped) < 60000 ? S.reset : formatSpan(clamped);
      const half = scrubPill.offsetWidth / 2;
      const px = Math.max(half, Math.min(p.width - half, x));
      scrubPill.style.transform = `translateX(${px - half}px)`;
      scrubPill.classList.add("on");
      footNote.textContent = state.pinned ? S.pinned : "";
    }
    tick(true);
  }

  rowsEl.addEventListener("pointermove", e => {
    if (state.pinned || !e.target.closest(".strip, .now-line, .scrub-line")) {
      if (!state.pinned && state.scrub != null && !e.target.closest(".strip")) setScrub(null);
      return;
    }
    scrubFromEvent(e);
  });
  rowsEl.addEventListener("pointerleave", () => { if (!state.pinned) setScrub(null); });
  document.documentElement.addEventListener("mouseleave", () => { if (!state.pinned) setScrub(null); });
  rowsEl.addEventListener("click", e => {
    if (!e.target.closest(".strip")) return;
    if (state.pinned) {
      state.pinned = false;
      scrubFromEvent(e);
    } else {
      state.pinned = true;
      scrubFromEvent(e);
      document.body.classList.add("pinned");
    }
    window.vaho?.haptic?.();
  });
  rowsEl.addEventListener("wheel", e => {
    if (!e.target.closest(".strip")) return;
    e.preventDefault();
    const step = (e.deltaY || e.deltaX) > 0 ? 900000 : -900000;
    state.pinned = true;
    document.body.classList.add("pinned");
    const base = state.scrub ?? Math.round(Date.now() / 900000) * 900000 - Date.now();
    setScrub(base + step);
  }, { passive: false });
  $("#reset").addEventListener("click", () => setScrub(null));

  function toggleClock() {
    state.h12 = !use12();
    save();
    rowsEl.querySelectorAll(".hm").forEach(el => { el.dataset.v = ""; el.innerHTML = ""; });
    rowsEl.querySelectorAll(".time").forEach(el => (el.title = use12() ? S.h24 : S.h12));
    tick(true);
    window.vaho?.haptic?.();
  }

  // ---------- add / remove ----------
  const allZones = (() => {
    try { return Intl.supportedValuesOf("timeZone"); } catch { return []; }
  })();

  function searchCities(q) {
    const norm = s => s.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
    const nq = norm(q.trim());
    if (!nq) return window.CITIES.filter(c => ["London", "New York", "Tokyo", "San Francisco", "Paris", "Sydney"].includes(c[0])).map(toResult);
    const out = [];
    const seen = new Set();
    for (const c of window.CITIES) {
      const name = norm(c[0]), country = norm(c[1]);
      let score = -1;
      if (name.startsWith(nq)) score = 3;
      else if (name.includes(nq)) score = 2;
      else if (country.startsWith(nq) || norm(c[2]).includes(nq)) score = 1;
      if (score >= 0) { out.push([score, toResult(c)]); seen.add(c[0] + c[2]); }
    }
    for (const z of allZones) {
      if (norm(z).includes(nq.replace(/ /g, "_")) && !window.CITIES.some(c => c[2] === z)) {
        out.push([0, { name: z.split("/").pop().replace(/_/g, " "), country: z.split("/")[0], tz: z }]);
      }
    }
    return out.sort((a, b) => b[0] - a[0]).slice(0, 6).map(x => x[1]);
  }
  const toResult = c => ({ name: c[0], country: c[1], tz: c[2] });

  const sheet = $("#sheet");
  const input = $("#search");
  const results = $("#results");
  let active = 0, current = [];

  function openSheet() {
    document.body.classList.add("adding");
    input.value = "";
    renderResults();
    resize(true);
    setTimeout(() => input.focus(), 60);
  }
  function closeSheet() {
    document.body.classList.remove("adding");
    input.blur();
    resize();
  }
  function renderResults() {
    current = searchCities(input.value);
    active = 0;
    const now = Date.now();
    results.innerHTML = current.length ? current.map((c, i) => {
      const z = zoned(c.tz, now);
      const h = use12() ? ((z.h + 11) % 12) + 1 : String(z.h).padStart(2, "0");
      const t = `${h}:${String(z.m).padStart(2, "0")}${use12() ? (z.h < 12 ? " AM" : " PM") : ""}`;
      const added = c.tz === localTZ || state.cities.some(x => x.name === c.name && x.tz === c.tz);
      return `<li class="${i === 0 ? "active" : ""}${added ? " added" : ""}" data-i="${i}" style="--i:${i}">
        <span class="dot" style="background:${sky(z.h + z.m / 60)}"></span>
        <span class="r-name">${escapeHTML(c.name)}<small>${escapeHTML(c.country)}</small></span>
        <span class="r-time">${t}</span></li>`;
    }).join("") : `<li class="empty">${S.none}</li>`;
  }
  function choose(i) {
    const c = current[i];
    if (!c) return;
    if (c.tz !== localTZ && !state.cities.some(x => x.name === c.name && x.tz === c.tz) && validZone(c.tz)) {
      state.cities.push({ name: c.name, tz: c.tz });
      save();
      closeSheet();
      build(state.cities.length);
    } else {
      closeSheet();
    }
    window.vaho?.haptic?.();
  }
  input.addEventListener("input", renderResults);
  input.addEventListener("keydown", e => {
    if (e.key === "ArrowDown" || e.key === "ArrowUp") {
      e.preventDefault();
      if (!current.length) return;
      active = (active + (e.key === "ArrowDown" ? 1 : -1) + current.length) % current.length;
      results.querySelectorAll("li").forEach((li, i) => li.classList.toggle("active", i === active));
    } else if (e.key === "Enter") {
      e.preventDefault();
      choose(active);
    } else if (e.key === "Escape") {
      closeSheet();
    }
  });
  results.addEventListener("click", e => {
    const li = e.target.closest("li[data-i]");
    if (li) choose(+li.dataset.i);
  });
  results.addEventListener("pointermove", e => {
    const li = e.target.closest("li[data-i]");
    if (!li || +li.dataset.i === active) return;
    active = +li.dataset.i;
    results.querySelectorAll("li").forEach((x, i) => x.classList.toggle("active", i === active));
  });
  $("#add").addEventListener("click", openSheet);
  $("#cancel").addEventListener("click", closeSheet);
  window.addEventListener("keydown", e => {
    if (e.key === "Escape") {
      if (document.body.classList.contains("adding")) closeSheet();
      else if (state.scrub != null) setScrub(null);
    }
  });

  function removeCity(index, row) {
    row.classList.add("leave");
    window.vaho?.haptic?.();
    setTimeout(() => {
      state.cities.splice(index, 1);
      save();
      build();
    }, 260);
  }

  function escapeHTML(s) {
    return String(s).replace(/[&<>"']/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[ch]);
  }

  // ---------- sizing / persistence ----------
  function resize(sheetOpen) {
    const n = allRows().length;
    const rows = sheetOpen ? Math.max(n, 5) : n;
    const h = 32 + 8 + Math.min(rows, 5) * 40 + 34;
    window.vaho?.notch?.setHeight(Math.max(150, Math.min(300, h))).catch?.(() => {});
    document.body.classList.toggle("many", n > 5);
  }

  function save() {
    const data = { cities: state.cities, h12: state.h12 };
    if (window.vaho?.storage) window.vaho.storage.set("clocks", data).catch(() => {});
  }

  async function load() {
    let data = null;
    try { data = await window.vaho.storage.get("clocks"); } catch {}
    if (data && Array.isArray(data.cities)) {
      state.cities = data.cities.filter(c => c && validZone(c.tz));
      state.h12 = data.h12 ?? null;
    } else {
      const localOffset = zoned(localTZ, Date.now()).offset;
      state.cities = [["New York", "America/New_York"], ["London", "Europe/London"], ["Tokyo", "Asia/Tokyo"]]
        .filter(([, tz]) => tz !== localTZ && zoned(tz, Date.now()).offset !== localOffset)
        .map(([name, tz]) => ({ name, tz }));
    }
  }

  // ---------- boot ----------
  $("#add-label").textContent = S.add;
  $("#reset").textContent = S.reset;
  input.placeholder = S.search;
  footNote.textContent = S.hint;

  let timer = null;
  function run() {
    clearInterval(timer);
    tick(true);
    timer = setInterval(() => tick(false), 250);
  }
  window.vaho?.on?.("visible", v => {
    if (v.visible) { paintStrips(); run(); } else { clearInterval(timer); setScrub(null); closeSheet(); }
  });
  new ResizeObserver(() => paintStrips()).observe(rowsEl);

  load().then(() => {
    build();
    run();
    setTimeout(() => document.body.classList.add("ready"), 30);
  });
})();
