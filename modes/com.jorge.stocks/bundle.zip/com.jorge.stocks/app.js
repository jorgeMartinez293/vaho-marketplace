// Stocks — a watchlist and a price chart for the notch.
//
// Quotes come from Yahoo Finance's chart endpoint, which needs no key. Page code can't
// reach the network in a vaho mode, so every request goes through vaho.net.fetch and the
// two hosts declared in the manifest's allowedHosts.

const API = "https://query1.finance.yahoo.com";

const RANGES = [
  { key: "1D", range: "1d",  interval: "5m"  },
  { key: "1W", range: "5d",  interval: "30m" },
  { key: "1M", range: "1mo", interval: "1d"  },
  { key: "6M", range: "6mo", interval: "1d"  },
  { key: "1Y", range: "1y",  interval: "1d"  }
];

const DEFAULT_WATCHLIST = [
  { symbol: "AAPL", name: "Apple Inc." },
  { symbol: "MSFT", name: "Microsoft Corporation" },
  { symbol: "NVDA", name: "NVIDIA Corporation" }
];

const REFRESH_MS = 60000;

const el = (id) => document.getElementById(id);
const state = {
  watchlist: DEFAULT_WATCHLIST.slice(),
  symbol: "AAPL",
  rangeKey: "1M",
  series: [],        // [{ t: epochSeconds, close: Number }]
  prevClose: null,
  currency: "USD",
  timer: null,
  visible: true
};

// MARK: - Network

async function api(path) {
  const r = await vaho.net.fetch(API + path);
  if (!r.ok) throw new Error("HTTP " + r.status);
  return r.json();
}

async function fetchChart(symbol, rangeKey) {
  const r = RANGES.find((x) => x.key === rangeKey) || RANGES[2];
  const data = await api(`/v8/finance/chart/${encodeURIComponent(symbol)}` +
                         `?range=${r.range}&interval=${r.interval}`);
  const result = data && data.chart && data.chart.result && data.chart.result[0];
  if (!result) throw new Error((data.chart && data.chart.error && data.chart.error.description) || "no data");
  const closes = (result.indicators.quote[0] || {}).close || [];
  // Yahoo pads the series with nulls for minutes the market skipped; drop those so the
  // line doesn't collapse to zero.
  const series = (result.timestamp || [])
    .map((t, i) => ({ t, close: closes[i] }))
    .filter((p) => typeof p.close === "number");
  const meta = result.meta || {};
  return {
    series,
    meta,
    prevClose: rangeKey === "1D" && typeof meta.chartPreviousClose === "number"
      ? meta.chartPreviousClose
      : (series.length ? series[0].close : null)
  };
}

async function search(query) {
  const data = await api(`/v1/finance/search?q=${encodeURIComponent(query)}&quotesCount=8&newsCount=0`);
  const wanted = ["EQUITY", "ETF", "INDEX", "MUTUALFUND", "CRYPTOCURRENCY"];
  return (data.quotes || [])
    .filter((q) => q.symbol && wanted.includes(q.quoteType))
    .map((q) => ({
      symbol: q.symbol,
      name: q.shortname || q.longname || q.symbol,
      exchange: q.exchDisp || q.exchange || ""
    }));
}

// MARK: - Formatting

function money(value, currency) {
  if (typeof value !== "number") return "—";
  try {
    return value.toLocaleString(undefined, {
      style: "currency", currency: currency || "USD",
      minimumFractionDigits: 2, maximumFractionDigits: 2
    });
  } catch {
    // An exchange can report a currency Intl doesn't know (some indices report none).
    return value.toFixed(2);
  }
}

function percent(value) {
  if (typeof value !== "number") return "—";
  return (value >= 0 ? "+" : "") + value.toFixed(2) + "%";
}

function stamp(seconds, rangeKey) {
  const d = new Date(seconds * 1000);
  const intraday = rangeKey === "1D" || rangeKey === "1W";
  return intraday
    ? d.toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })
    : d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

// MARK: - Chart

const VIEW = { w: 360, h: 116, top: 10, bottom: 8 };

function chartGeometry() {
  const values = state.series.map((p) => p.close);
  if (!values.length) return null;
  const baseline = typeof state.prevClose === "number" ? state.prevClose : values[0];
  let lo = Math.min(...values, baseline);
  let hi = Math.max(...values, baseline);
  if (hi === lo) { hi += 1; lo -= 1; }            // a flat series would divide by zero
  const pad = (hi - lo) * 0.08;
  lo -= pad; hi += pad;
  const span = state.series.length > 1 ? state.series.length - 1 : 1;
  const x = (i) => (i / span) * VIEW.w;
  const y = (v) => VIEW.top + (1 - (v - lo) / (hi - lo)) * (VIEW.h - VIEW.top - VIEW.bottom);
  return { x, y, baseline };
}

function drawChart() {
  const svg = el("chart");
  const geo = chartGeometry();
  // Redrawing replaces the cursor group, so any readout still on screen would keep showing
  // a price from the series that was just thrown away.
  hideCursor();
  if (!geo) { svg.innerHTML = ""; return; }

  const last = state.series[state.series.length - 1].close;
  const up = last >= geo.baseline;
  const color = up ? "var(--up)" : "var(--down)";
  const line = state.series.map((p, i) => `${i ? "L" : "M"}${geo.x(i).toFixed(2)},${geo.y(p.close).toFixed(2)}`).join("");
  const area = `${line}L${VIEW.w},${VIEW.h}L0,${VIEW.h}Z`;

  svg.innerHTML = `
    <defs>
      <linearGradient id="fill" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="${color}" stop-opacity="0.30"/>
        <stop offset="100%" stop-color="${color}" stop-opacity="0"/>
      </linearGradient>
    </defs>
    <line x1="0" y1="${geo.y(geo.baseline).toFixed(2)}" x2="${VIEW.w}" y2="${geo.y(geo.baseline).toFixed(2)}"
          stroke="var(--vaho-tint-12)" stroke-width="1" stroke-dasharray="3 3"/>
    <path d="${area}" fill="url(#fill)"/>
    <path d="${line}" fill="none" stroke="${color}" stroke-width="1.6"
          stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"/>
    <g id="cursor" opacity="0">
      <line y1="${VIEW.top}" y2="${VIEW.h - VIEW.bottom}" stroke="var(--vaho-tint-50)" stroke-width="1"
            vector-effect="non-scaling-stroke"/>
      <circle r="2.6" fill="${color}" stroke="#000" stroke-width="0.8"/>
    </g>`;
}

// The chart is stretched by preserveAspectRatio="none", so the pointer's x has to be mapped
// through the element's real width rather than read off the viewBox.
function pointIndexFor(clientX) {
  const box = el("chart").getBoundingClientRect();
  if (!box.width || state.series.length < 2) return 0;
  const ratio = Math.min(1, Math.max(0, (clientX - box.left) / box.width));
  return Math.round(ratio * (state.series.length - 1));
}

function showCursor(clientX) {
  const geo = chartGeometry();
  const cursor = document.getElementById("cursor");
  if (!geo || !cursor) return;
  const i = pointIndexFor(clientX);
  const point = state.series[i];
  const x = geo.x(i);
  const y = geo.y(point.close);
  cursor.setAttribute("opacity", "1");
  cursor.querySelector("line").setAttribute("x1", x);
  cursor.querySelector("line").setAttribute("x2", x);
  cursor.querySelector("circle").setAttribute("cx", x);
  cursor.querySelector("circle").setAttribute("cy", y);

  const readout = el("readout");
  const delta = geo.baseline ? ((point.close - geo.baseline) / geo.baseline) * 100 : 0;
  readout.hidden = false;
  readout.textContent = `${money(point.close, state.currency)} · ${percent(delta)} · ${stamp(point.t, state.rangeKey)}`;
  // Keep the bubble inside the panel at both ends of the chart.
  readout.style.left = `${Math.min(88, Math.max(12, (x / VIEW.w) * 100))}%`;
}

function hideCursor() {
  const cursor = document.getElementById("cursor");
  if (cursor) cursor.setAttribute("opacity", "0");
  el("readout").hidden = true;
}

// MARK: - Render

function renderChips() {
  const chips = el("chips");
  chips.innerHTML = "";
  for (const item of state.watchlist) {
    const chip = document.createElement("button");
    chip.className = "chip" + (item.symbol === state.symbol ? " on" : "");
    chip.textContent = item.symbol;
    chip.title = item.name || item.symbol;
    chip.onclick = () => select(item.symbol);
    if (state.watchlist.length > 1) {
      const x = document.createElement("span");
      x.className = "x";
      x.textContent = "×";
      x.title = "Remove";
      x.onclick = (event) => { event.stopPropagation(); remove(item.symbol); };
      chip.appendChild(x);
    }
    chips.appendChild(chip);
  }
}

function renderRanges() {
  const box = el("ranges");
  box.innerHTML = "";
  for (const r of RANGES) {
    const chip = document.createElement("button");
    chip.className = "chip" + (r.key === state.rangeKey ? " on" : "");
    chip.textContent = r.key;
    chip.onclick = () => {
      state.rangeKey = r.key;
      vaho.storage.set("rangeKey", r.key);
      renderRanges();
      load();
    };
    box.appendChild(chip);
  }
}

function renderQuote(meta) {
  const last = state.series.length ? state.series[state.series.length - 1].close : null;
  const price = typeof meta.regularMarketPrice === "number" ? meta.regularMarketPrice : last;
  const baseline = state.prevClose;
  const delta = (typeof price === "number" && baseline) ? ((price - baseline) / baseline) * 100 : null;

  el("symbol").textContent = meta.symbol || state.symbol;
  el("name").textContent = meta.shortName || meta.longName || "";
  el("price").textContent = money(price, state.currency);
  const change = el("change");
  change.textContent = percent(delta) + (state.rangeKey === "1D" ? "" : ` · ${state.rangeKey}`);
  change.className = "change vaho-mono " + (delta >= 0 ? "up" : "down");

  const when = meta.regularMarketTime
    ? new Date(meta.regularMarketTime * 1000).toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })
    : "";
  el("status").textContent = when ? `Yahoo Finance · ${when}` : "Yahoo Finance";
}

function setStatus(text) {
  el("status").textContent = text;
}

// MARK: - Actions

async function load() {
  try {
    setStatus("Loading…");
    const { series, meta, prevClose } = await fetchChart(state.symbol, state.rangeKey);
    if (!series.length) throw new Error("no prices for this range");
    state.series = series;
    state.prevClose = prevClose;
    state.currency = meta.currency || "USD";
    drawChart();
    renderQuote(meta);
  } catch (error) {
    vaho.log("stocks: load failed", String(error));
    setStatus("Couldn't load " + state.symbol + " — " + String(error.message || error));
  }
}

function select(symbol) {
  if (symbol === state.symbol) return;
  state.symbol = symbol;
  state.series = [];
  vaho.storage.set("symbol", symbol);
  renderChips();
  el("chart").innerHTML = "";
  hideCursor();
  load();
  vaho.haptic();
}

function remove(symbol) {
  state.watchlist = state.watchlist.filter((x) => x.symbol !== symbol);
  vaho.storage.set("watchlist", state.watchlist);
  if (symbol === state.symbol && state.watchlist.length) {
    state.symbol = state.watchlist[0].symbol;
    vaho.storage.set("symbol", state.symbol);
    load();
  }
  renderChips();
}

function add(entry) {
  if (!state.watchlist.some((x) => x.symbol === entry.symbol)) {
    state.watchlist.push(entry);
    vaho.storage.set("watchlist", state.watchlist);
  }
  showSearch(false);
  state.symbol = entry.symbol;
  vaho.storage.set("symbol", entry.symbol);
  renderChips();
  load();
}

function showSearch(on) {
  el("search").hidden = !on;
  el("quote").hidden = on;
  if (on) {
    el("q").value = "";
    el("results").innerHTML = "";
    el("search-status").textContent = "Type at least two characters.";
    el("q").focus();
  }
}

function renderResults(items) {
  const list = el("results");
  list.innerHTML = "";
  for (const item of items) {
    const li = document.createElement("li");
    li.innerHTML = `<span class="sym"></span><span class="nm vaho-grow"></span><span class="exch"></span>`;
    li.querySelector(".sym").textContent = item.symbol;
    li.querySelector(".nm").textContent = item.name;
    li.querySelector(".exch").textContent = item.exchange;
    li.onclick = () => add(item);
    list.appendChild(li);
  }
  el("search-status").textContent = items.length ? "" : "Nothing found.";
}

// MARK: - Wiring

el("add").onclick = () => showSearch(true);
el("cancel").onclick = () => showSearch(false);

let searchTimer = null;
el("q").oninput = () => {
  const query = el("q").value.trim();
  clearTimeout(searchTimer);
  if (query.length < 2) {
    el("results").innerHTML = "";
    el("search-status").textContent = "Type at least two characters.";
    return;
  }
  el("search-status").textContent = "Searching…";
  // Debounced: the field fires per keystroke and every call is a real request.
  searchTimer = setTimeout(async () => {
    try {
      renderResults(await search(query));
    } catch (error) {
      el("search-status").textContent = "Search failed — " + String(error.message || error);
    }
  }, 280);
};

const chartWrap = el("chart-wrap");
chartWrap.addEventListener("pointermove", (event) => showCursor(event.clientX));
chartWrap.addEventListener("pointerleave", hideCursor);

function startTimer() {
  clearInterval(state.timer);
  state.timer = setInterval(() => { if (state.visible) load(); }, REFRESH_MS);
}

// The panel is unmounted while the notch is collapsed but the page keeps running, so the
// refresh has to stop itself instead of polling a quote nobody is looking at.
vaho.on("visible", (v) => {
  state.visible = !!v.visible;
  if (state.visible) { load(); startTimer(); } else { clearInterval(state.timer); hideCursor(); }
});

// The line color is fixed, but the baseline and cursor use tint variables the host updates.
vaho.on("theme", () => { if (state.series.length) drawChart(); });

(async function boot() {
  try {
    const [watchlist, symbol, rangeKey] = await Promise.all([
      vaho.storage.get("watchlist"),
      vaho.storage.get("symbol"),
      vaho.storage.get("rangeKey")
    ]);
    if (Array.isArray(watchlist) && watchlist.length) state.watchlist = watchlist;
    if (symbol && state.watchlist.some((x) => x.symbol === symbol)) state.symbol = symbol;
    else state.symbol = state.watchlist[0].symbol;
    if (RANGES.some((r) => r.key === rangeKey)) state.rangeKey = rangeKey;
  } catch (error) {
    vaho.log("stocks: storage unavailable", String(error));
  }
  renderChips();
  renderRanges();
  await load();
  startTimer();
})();
