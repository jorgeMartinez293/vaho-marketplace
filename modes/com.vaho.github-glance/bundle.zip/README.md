# GitHub Glance

Open PRs + combined CI status for one repo, click to open in the browser.

## Setup

1. Gear icon → `owner/repo` (e.g. `torvalds/linux`).
2. Optional: a personal access token (classic, no scopes needed for public
   repos; `repo` scope for private ones) — raises the rate limit from 60/hr
   to 5000/hr and is required for private repos.

Dots: green = all checks passed, yellow (pulsing) = running, red = a check
failed, grey = no checks reported yet.

Auto-refreshes every 5 minutes and caches a PR's check status by commit SHA
(a finished result never changes) — unauthenticated stays well under
GitHub's 60 requests/hour even with several PRs open. Use the ↻ button for
an immediate check.
