# Obsidian Search

Full-text vault search from the notch, results open straight in Obsidian.

## Setup

1. Install and enable the **Local REST API** community plugin in Obsidian.
2. Grab its API key and base URL (`http://127.0.0.1:27123` if you enabled
   the plugin's non-encrypted HTTP server, `https://127.0.0.1:27124`
   otherwise — the self-signed cert may not validate everywhere).
3. Open this mode's settings (gear icon): base URL, API key, and your
   **vault name exactly as it appears in Obsidian** (needed to build the
   `obsidian://open` link).
4. Type to search; click a result to jump into Obsidian.

Shares no state with Obsidian Capture — each mode keeps its own settings.
