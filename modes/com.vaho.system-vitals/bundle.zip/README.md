# System Vitals

A more detailed alternative to the built-in System mode: rolling graphs
(not just current value) with min/avg/peak per metric, session-cumulative
network transfer, battery charge/state, adjustable poll interval (1/2/5s)
and a pause toggle so the graphs freeze while you read them.

No setup, no permissions beyond `system` and `battery` — install and go.
