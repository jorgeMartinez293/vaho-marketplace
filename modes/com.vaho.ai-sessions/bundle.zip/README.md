# AI Sessions

Glance at what's running: LM Studio's server (polled directly — it has a
real local HTTP API), plus Claude Code and Codex CLI activity (no such
API exists for those two, so this mode leans on a small Shortcut you
build once).

## LM Studio

Nothing to set up beyond turning its local server on (LM Studio → Developer
→ Start Server, default `http://127.0.0.1:1234`). If you changed the port,
update it in this mode's settings (gear icon). The mode tries the current
REST API (`/api/v1/models`, shows loaded vs. not loaded per model) and
falls back to the OpenAI-compatible `/v1/models` (just a name list, no
loaded state) on older LM Studio versions. Authentication is off by
default in LM Studio — if you turned it on (Server Settings → Require
Authentication), paste the API token in this mode's settings too.

## Claude Code / Codex — one-time Shortcut

1. Open **Shortcuts.app** → **+** (new shortcut).
2. Name it exactly **vaho ai sessions** (or pick your own name and set it
   in this mode's settings).
3. Add a **Run Shell Script** action, shell `/bin/zsh`, pass input **as
   arguments** (unused), with this script:

   ```sh
   claude_n=$(pgrep -fc "[c]laude" 2>/dev/null || echo 0)
   codex_n=$(pgrep -fc "[c]odex" 2>/dev/null || echo 0)
   printf '[{"tool":"Claude Code","count":%s},{"tool":"Codex","count":%s}]' "$claude_n" "$codex_n"
   ```

   (the `[c]laude` / `[c]odex` bracket trick keeps `pgrep` from matching its
   own grep process.)
4. Make sure the Run Shell Script action is the **last** action — Shortcuts
   returns its stdout as the shortcut's result automatically.
5. Run it once from Shortcuts.app to grant the Terminal/Shell permission
   prompt.

The mode polls this Shortcut every 8 seconds while its panel is open and
expects a JSON array of `{ "tool": "...", "count": N }` (or `"status"` /
`"detail"` strings) — extend the script to grep for other tools the same
way.
